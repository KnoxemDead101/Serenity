"""
Transaction service: the business rules for transactions.

    api/transactions.py  ->  services/transaction_service.py  ->  database

What lives here:
- how a transaction's direction becomes a signed amount (the ONE place
  that decides whether money is added or subtracted),
- recording, listing, editing and soft-deleting transactions,
- the correction history that keeps a frozen copy of every edit/delete.

This code used to live in account_service.py. It moved here so accounts
and transactions each have their own file (v0.2 handoff, section 37).
"""

from sqlalchemy import select
from sqlalchemy.orm import Session

from models.account import Account, utc_now
from models.transaction import Transaction
from models.transaction_correction import TransactionCorrection
from schemas.transaction import (
    TransactionCorrectionRead,
    TransactionCreate,
    TransactionRead,
    TransactionSnapshot,
    TransactionUpdate,
)
from utils.money import cents_to_dollars, dollars_to_cents


# ---------------------------------------------------------------------------
# Direction
# ---------------------------------------------------------------------------

def signed_amount_cents(transaction: Transaction) -> int:
    """
    The effect of one transaction on its account balance, in cents.

    Income adds money, Expense removes it. Amounts are stored positive,
    so this function is the only place a minus sign is applied.
    """
    if transaction.transaction_type == "Income":
        return transaction.amount_cents
    if transaction.transaction_type == "Expense":
        return -transaction.amount_cents
    # Validation only allows Income/Expense, so reaching this line means
    # the database holds a value we don't understand. Fail loudly rather
    # than guess and produce a wrong balance.
    raise ValueError(f"Unknown transaction type: {transaction.transaction_type!r}")


def active_balance_change_cents(account: Account) -> int:
    """Sum of every non-deleted transaction's effect on this account."""
    return sum(
        signed_amount_cents(transaction)
        for transaction in account.transactions
        if transaction.deleted_at is None
    )


# ---------------------------------------------------------------------------
# Recording and editing
# ---------------------------------------------------------------------------

def resolve_classification(account: Account, requested: str | None) -> str:
    """Use the chosen classification, or fall back to the account's."""
    return requested if requested is not None else account.classification


def _apply_fields(
    transaction: Transaction, account: Account, data: TransactionCreate
) -> None:
    """Copy validated form data onto a transaction (shared by create/update)."""
    transaction.date = data.date
    transaction.transaction_type = data.transaction_type
    transaction.classification = resolve_classification(account, data.classification)
    transaction.amount_cents = dollars_to_cents(data.amount)
    transaction.description = data.description
    transaction.merchant = data.merchant
    transaction.location = data.location
    transaction.category = data.category
    transaction.subcategory = data.subcategory


def create_transaction(
    db: Session, account: Account, data: TransactionCreate
) -> Transaction:
    transaction = Transaction()
    _apply_fields(transaction, account, data)
    account.transactions.append(transaction)
    db.commit()
    db.refresh(transaction)
    return transaction


def list_transactions(db: Session, account_id: int) -> list[Transaction]:
    """Active (not deleted) transactions, newest first."""
    return list(db.scalars(
        select(Transaction)
        .where(Transaction.account_id == account_id, Transaction.deleted_at.is_(None))
        .order_by(Transaction.date.desc(), Transaction.id.desc())
    ))


def get_transaction(
    db: Session, account_id: int, transaction_id: int
) -> Transaction | None:
    """Return a transaction only when it belongs to the requested account."""
    return db.scalar(
        select(Transaction).where(
            Transaction.id == transaction_id,
            Transaction.account_id == account_id,
            Transaction.deleted_at.is_(None),
        )
    )


def update_transaction(
    db: Session, transaction: Transaction, data: TransactionUpdate
) -> Transaction:
    before = transaction_snapshot(transaction)
    _apply_fields(transaction, transaction.account, data)
    record_correction(db, transaction, "Updated", before)
    db.commit()
    db.refresh(transaction)
    return transaction


def delete_transaction(db: Session, transaction: Transaction) -> None:
    """Soft delete: hide it from balances and history, but keep the row."""
    before = transaction_snapshot(transaction)
    transaction.deleted_at = utc_now()
    record_correction(db, transaction, "Deleted", before)
    db.commit()


# ---------------------------------------------------------------------------
# Correction history
# ---------------------------------------------------------------------------

def transaction_snapshot(transaction: Transaction) -> dict:
    """Portable JSON snapshot; cents are stored as integers, never floats."""
    return {
        "date": transaction.date.isoformat(),
        "transaction_type": transaction.transaction_type,
        "classification": transaction.classification,
        "amount_cents": transaction.amount_cents,
        "description": transaction.description,
        "merchant": transaction.merchant,
        "location": transaction.location,
        "category": transaction.category,
        "subcategory": transaction.subcategory,
    }


def record_correction(
    db: Session, transaction: Transaction, action: str, before: dict
) -> None:
    db.add(TransactionCorrection(
        account_id=transaction.account_id,
        transaction_id=transaction.id,
        action=action,
        changed_at=utc_now(),
        before=before,
        after=transaction_snapshot(transaction) if action == "Updated" else None,
    ))


def list_corrections(db: Session, account_id: int) -> list[TransactionCorrection]:
    return list(db.scalars(
        select(TransactionCorrection)
        .where(TransactionCorrection.account_id == account_id)
        .order_by(TransactionCorrection.changed_at.desc(), TransactionCorrection.id.desc())
    ))


def _snapshot_from_json(data: dict) -> TransactionSnapshot:
    # .get() because snapshots saved before this change lack the newer keys.
    return TransactionSnapshot(
        date=data["date"],
        transaction_type=data["transaction_type"],
        amount=cents_to_dollars(data["amount_cents"]),
        description=data["description"],
        category=data.get("category"),
        classification=data.get("classification"),
        merchant=data.get("merchant"),
        location=data.get("location"),
        subcategory=data.get("subcategory"),
    )


def to_correction_read(correction: TransactionCorrection) -> TransactionCorrectionRead:
    return TransactionCorrectionRead(
        id=correction.id,
        transaction_id=correction.transaction_id,
        action=correction.action,
        changed_at=correction.changed_at,
        before=_snapshot_from_json(correction.before),
        after=_snapshot_from_json(correction.after) if correction.after is not None else None,
    )


def to_transaction_read(transaction: Transaction) -> TransactionRead:
    return TransactionRead(
        id=transaction.id,
        account_id=transaction.account_id,
        date=transaction.date,
        transaction_type=transaction.transaction_type,
        classification=transaction.classification,
        amount=cents_to_dollars(transaction.amount_cents),
        description=transaction.description,
        merchant=transaction.merchant,
        location=transaction.location,
        category=transaction.category,
        subcategory=transaction.subcategory,
        created_at=transaction.created_at,
        updated_at=transaction.updated_at,
    )
