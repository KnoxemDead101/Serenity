# Serenity Architecture

## Layered flow

```text
frontend/  HTML, CSS, JavaScript; input and display only
    ↓ HTTP + JSON
api/       FastAPI routes; HTTP concerns and status codes
    ↓
schemas/   Pydantic input validation and response shapes
    ↓
services/  business rules and financial calculations
    ↓
models/    SQLAlchemy persistence models
    ↓
storage/   SQLite or PostgreSQL connection
```

Shared exact-value helpers live in `utils/`. Automated tests live in `tests/`.

## Main domains

| Domain | API | Schemas | Service |
|---|---|---|---|
| Accounts | `api/accounts.py` | `schemas/account.py` | `account_service`: creates accounts, derives current balances, account-only totals |
| Transactions | `api/transactions.py` | `schemas/transaction.py` | `transaction_service`: records, edits and soft-deletes transactions; keeps correction history; decides each transaction's sign |
| Bills, debts, investments | `api/finance.py` | `schemas/finance.py` | `finance_service`: obligations, liabilities, starting-position investments and summaries |
| Businesses | `api/businesses.py` | `schemas/business.py` | `business_service`: create, rename, deactivate; unique names |
| Dependents | `api/dependents.py` | `schemas/dependent.py` | `dependent_service`: same, for children |
| Export | `api/export.py` | (plain JSON/CSV) | `export_service`: complete backup |
| Dashboard | `api/dashboard.py` | `schemas/dashboard.py` | `dashboard_service`: combines independent summaries; owns the net-worth formula |

- `account_service` asks `transaction_service` for active transaction balance
  changes; it never decides direction itself.
- Rules that need the database (inactive account, business/dependent link
  rules) live in `transaction_service` and raise `TransactionRuleError`, which
  the API returns as HTTP 422 with a readable message.
- Each total has exactly one formula: `account_service.total_balance_cents`,
  `finance_service.total_debt_balance_cents`,
  `finance_service.total_investment_value_cents`,
  `finance_service.normalized_monthly_bill_total_cents`.
- Net worth (`dashboard_service.calculate_net_worth_cents`) =
  account balances + investment value − debt balances, all in cents,
  converted to dollars once at the end.
- Credit cards are Debts, not Accounts, which prevents double-counting.

## Exact values

- Money is stored as integer cents.
- Debt APR is stored as thousandths of a percent. `6.875%` becomes `6875`.
- Investment quantity is stored as integer units where one whole unit equals
  `100,000,000` stored units.
- Recurring bills are summed in twelfths of a cent and rounded once using
  round-half-up. Monthly bills contribute 12/12, quarterly 4/12, annual 1/12,
  and one-time bills are excluded.
- Every timestamp is time-zone-aware UTC (`DateTime(timezone=True)`, migration
  `0005`). The browser converts to local time only for display.

## Database lifecycle

`storage/database.py` selects SQLite when no database URL is supplied and
PostgreSQL when Replit supplies `DATABASE_URL`. Alembic migrations are the
schema source of truth. Application startup never creates or alters tables.

### Development (Replit workspace or your PC)

1. Change a model.
2. `alembic revision --autogenerate -m "describe the change"`. Prefer running
   this against the development PostgreSQL database (Replit Shell), which
   reports types most accurately.
3. Read and edit the generated file, then `alembic upgrade head`.
4. `pytest`.

### Production (the published app)

Replit Publish compares the development database structure with production
and applies the difference **before** the app starts. Production therefore
does **not** run Alembic. If it did, Alembic would try to create tables Replit
already created and fail. Other Replit + Alembic projects have hit exactly
this conflict.

**Before every Publish** run `bash scripts/prepublish_check.sh`. It migrates the
development database, confirms it is at the latest revision, and runs the
tests. Publish then mirrors a verified structure.

### Data changes

Replit Publish copies **structure only**. A migration that changes data (like
`0004`, which renamed Deposit/Withdrawal to Income/Expense) does not reach
production. Production held no transactions when `0004` shipped, so nothing
was missed.

Once production holds real data, a data change ships as:

1. a normal migration (so development and tests stay correct), and
2. a one-time, idempotent script in `scripts/data_fixes/`, for example
   `UPDATE … WHERE old_value`, which is safe to run twice. Run it once from the
   Replit Shell against production and record the date here.

Data fixes applied to production: *none yet.*

## API paths

Serenity APIs use `/serenity-api`:

- `/serenity-api/accounts` (+ `/{id}`, `PUT /{id}`, `POST /{id}/deactivate`, `POST /{id}/reactivate`)
- `/serenity-api/accounts/{id}/transactions` (+ `PUT`/`DELETE /{transaction_id}`)
- `/serenity-api/accounts/{id}/transaction-corrections`
- `/serenity-api/transactions/options` (includes active businesses and dependents)
- `/serenity-api/businesses`, `/serenity-api/dependents` (each with `PUT /{id}`,
  `POST /{id}/deactivate`, `POST /{id}/reactivate`; duplicate names → 409)
- `/serenity-api/bills`, `/debts`, `/investments` (each with `/{id}`, `PUT /{id}`,
  `POST /{id}/deactivate`, `POST /{id}/reactivate`)
- `/serenity-api/dashboard/summary`
- `/serenity-api/finance/summary`
- `/serenity-api/export` (full JSON backup) and `/serenity-api/export/transactions.csv`

Records are never hard-deleted; see "Nothing is hard-deleted" in
`docs/data-model.md`.

## Backup / export

`services/export_service.py` builds a complete backup: every table,
including deactivated records, soft-deleted transactions and the
correction history. Money appears as exact cents **and** as a dollar
string, never a float. The file records `schema_version` (the Alembic
revision) so a future restore tool knows which structure it came from.
There is no import/restore yet.

The export routes return all financial data, so the published app must
be private (Replit "Invite only").

## Tests

- `pytest` runs everywhere. API and service tests use in-memory SQLite;
  `test_migrations.py` builds SQLite files from the migrations and checks
  upgrade/downgrade.
- Browser tests (`test_accounts_browser.py`) need Playwright and Chromium.
  They run on Replit and are skipped elsewhere.

## Development rules

- Keep routes thin.
- Keep calculations out of JavaScript.
- Store authoritative facts and calculate derived results.
- Add a migration whenever a model changes.
- Review generated migrations before applying them.
- Keep explanatory comments; don't compact files.
- Never collect bank credentials.
