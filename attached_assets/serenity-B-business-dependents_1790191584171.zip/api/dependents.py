"""
Dependent API routes.

    GET  /serenity-api/dependents                   list (active and inactive)
    POST /serenity-api/dependents                   create
    PUT  /serenity-api/dependents/{id}              rename / edit notes
    POST /serenity-api/dependents/{id}/deactivate   stop offering them for new transactions
    POST /serenity-api/dependents/{id}/reactivate   bring them back

A duplicate display name answers 409 Conflict.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from models.dependent import Dependent
from schemas.dependent import DependentCreate, DependentRead, DependentUpdate
from services import dependent_service
from storage.database import get_db

router = APIRouter(prefix="/serenity-api/dependents", tags=["Dependents"])


def _require_dependent(db: Session, dependent_id: int) -> Dependent:
    dependent = dependent_service.get_dependent(db, dependent_id)
    if dependent is None:
        raise HTTPException(status_code=404, detail="Dependent not found")
    return dependent


@router.get("", response_model=list[DependentRead])
def list_dependents(db: Session = Depends(get_db)):
    return [dependent_service.to_dependent_read(d) for d in dependent_service.list_dependents(db)]


@router.post("", response_model=DependentRead, status_code=status.HTTP_201_CREATED)
def create_dependent(data: DependentCreate, db: Session = Depends(get_db)):
    try:
        dependent = dependent_service.create_dependent(db, data)
    except dependent_service.NameTakenError as error:
        raise HTTPException(status_code=409, detail=str(error))
    return dependent_service.to_dependent_read(dependent)


@router.put("/{dependent_id}", response_model=DependentRead)
def update_dependent(dependent_id: int, data: DependentUpdate, db: Session = Depends(get_db)):
    dependent = _require_dependent(db, dependent_id)
    try:
        dependent = dependent_service.update_dependent(db, dependent, data)
    except dependent_service.NameTakenError as error:
        raise HTTPException(status_code=409, detail=str(error))
    return dependent_service.to_dependent_read(dependent)


@router.post("/{dependent_id}/deactivate", response_model=DependentRead)
def deactivate_dependent(dependent_id: int, db: Session = Depends(get_db)):
    dependent = dependent_service.set_dependent_active(
        db, _require_dependent(db, dependent_id), False
    )
    return dependent_service.to_dependent_read(dependent)


@router.post("/{dependent_id}/reactivate", response_model=DependentRead)
def reactivate_dependent(dependent_id: int, db: Session = Depends(get_db)):
    dependent = dependent_service.set_dependent_active(
        db, _require_dependent(db, dependent_id), True
    )
    return dependent_service.to_dependent_read(dependent)
