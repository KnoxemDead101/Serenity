"""
Business API routes.

    GET  /serenity-api/businesses                   list (active and inactive)
    POST /serenity-api/businesses                   create
    PUT  /serenity-api/businesses/{id}              rename / edit notes
    POST /serenity-api/businesses/{id}/deactivate   stop offering it for new transactions
    POST /serenity-api/businesses/{id}/reactivate   bring it back

A duplicate name answers 409 Conflict.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from models.business import Business
from schemas.business import BusinessCreate, BusinessRead, BusinessUpdate
from services import business_service
from storage.database import get_db

router = APIRouter(prefix="/serenity-api/businesses", tags=["Businesses"])


def _require_business(db: Session, business_id: int) -> Business:
    business = business_service.get_business(db, business_id)
    if business is None:
        raise HTTPException(status_code=404, detail="Business not found")
    return business


@router.get("", response_model=list[BusinessRead])
def list_businesses(db: Session = Depends(get_db)):
    return [business_service.to_business_read(b) for b in business_service.list_businesses(db)]


@router.post("", response_model=BusinessRead, status_code=status.HTTP_201_CREATED)
def create_business(data: BusinessCreate, db: Session = Depends(get_db)):
    try:
        business = business_service.create_business(db, data)
    except business_service.NameTakenError as error:
        raise HTTPException(status_code=409, detail=str(error))
    return business_service.to_business_read(business)


@router.put("/{business_id}", response_model=BusinessRead)
def update_business(business_id: int, data: BusinessUpdate, db: Session = Depends(get_db)):
    business = _require_business(db, business_id)
    try:
        business = business_service.update_business(db, business, data)
    except business_service.NameTakenError as error:
        raise HTTPException(status_code=409, detail=str(error))
    return business_service.to_business_read(business)


@router.post("/{business_id}/deactivate", response_model=BusinessRead)
def deactivate_business(business_id: int, db: Session = Depends(get_db)):
    business = business_service.set_business_active(db, _require_business(db, business_id), False)
    return business_service.to_business_read(business)


@router.post("/{business_id}/reactivate", response_model=BusinessRead)
def reactivate_business(business_id: int, db: Session = Depends(get_db)):
    business = business_service.set_business_active(db, _require_business(db, business_id), True)
    return business_service.to_business_read(business)
