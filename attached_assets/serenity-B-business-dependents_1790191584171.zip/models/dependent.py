"""
Dependent database model.

A lightweight label so Serenity can understand spending for each child
(e.g. "Child 1", "Child 2", and a separate "Shared / All Children"
record). This is NOT a child-management app: only a display name and
optional notes. No birthdates, no ID numbers, nothing sensitive.

There are deliberately NO responsibility percentages here. Shared costs
are recorded against the "Shared" dependent and reported separately;
they are never split into the individual children automatically.

Dependents are never deleted, only deactivated.
"""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, Text, UniqueConstraint, true
from sqlalchemy.orm import Mapped, mapped_column

from models.account import utc_now
from storage.database import Base


class Dependent(Base):
    __tablename__ = "dependents"
    __table_args__ = (UniqueConstraint("display_name", name="uq_dependents_display_name"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    display_name: Mapped[str] = mapped_column(String(100), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, onupdate=utc_now
    )
