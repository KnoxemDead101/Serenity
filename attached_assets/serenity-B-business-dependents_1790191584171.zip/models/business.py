"""
Business database model.

A lightweight label for financial activity that belongs to a business
(the first one is KTT; nothing about KTT is hardcoded). A transaction can
point at a Business. This is NOT an accounting system: no ledgers, no
tax logic, just "this money was for that business."

Businesses are never deleted, only deactivated, so old transactions keep
their link.
"""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, Text, UniqueConstraint, true
from sqlalchemy.orm import Mapped, mapped_column

from models.account import utc_now
from storage.database import Base


class Business(Base):
    __tablename__ = "businesses"
    # Constraint names match migration 0007 exactly.
    __table_args__ = (UniqueConstraint("name", name="uq_businesses_name"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, onupdate=utc_now
    )
