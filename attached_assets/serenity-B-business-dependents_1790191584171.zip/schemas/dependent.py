"""Dependent schemas: what the API accepts and returns for dependents."""

from datetime import datetime

from pydantic import BaseModel, field_validator

from utils.validators import optional_text, require_text


class DependentCreate(BaseModel):
    display_name: str
    notes: str | None = None

    @field_validator("display_name")
    @classmethod
    def check_display_name(cls, value: str) -> str:
        return require_text(value, "Display name")

    @field_validator("notes")
    @classmethod
    def check_notes(cls, value: str | None) -> str | None:
        return optional_text(value, max_length=1000)


class DependentUpdate(DependentCreate):
    """Same rules as creating; every field is sent again."""


class DependentRead(BaseModel):
    id: int
    display_name: str
    notes: str | None
    active: bool
    created_at: datetime
    updated_at: datetime
