"""Add Businesses and Dependents, and optional links from transactions.

Revision ID: 0007_business_and_dependents
Revises: 0006_active_flags

WHAT IT DOES
------------
1. Creates `businesses` (e.g. KTT) and `dependents` (e.g. Child 1,
   Child 2, Shared / All Children). Names are unique.
2. Adds two OPTIONAL columns to `transactions`: `business_id` and
   `dependent_id`, each a foreign key. Existing transactions simply get
   NULL (no link).

Constraint names are spelled out so SQLite, which rebuilds the table
for these changes, and PostgreSQL end up with identical names. That
lets the downgrade drop them by name.

Structure only, no data values change, so this is safe with Replit
Publish copying structure to production.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "0007_business_and_dependents"
down_revision: Union[str, None] = "0006_active_flags"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "businesses",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("name", name="uq_businesses_name"),
    )
    op.create_table(
        "dependents",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("display_name", sa.String(length=100), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("display_name", name="uq_dependents_display_name"),
    )
    with op.batch_alter_table("transactions") as batch:
        batch.add_column(sa.Column("business_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("dependent_id", sa.Integer(), nullable=True))
        batch.create_foreign_key(
            "fk_transactions_business_id", "businesses", ["business_id"], ["id"]
        )
        batch.create_foreign_key(
            "fk_transactions_dependent_id", "dependents", ["dependent_id"], ["id"]
        )


def downgrade() -> None:
    with op.batch_alter_table("transactions") as batch:
        batch.drop_constraint("fk_transactions_dependent_id", type_="foreignkey")
        batch.drop_constraint("fk_transactions_business_id", type_="foreignkey")
        batch.drop_column("dependent_id")
        batch.drop_column("business_id")
    op.drop_table("dependents")
    op.drop_table("businesses")
