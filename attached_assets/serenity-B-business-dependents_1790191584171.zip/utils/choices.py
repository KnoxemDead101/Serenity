"""
Fixed lists of allowed values ("choices").

Keeping these in one file means the backend validation, the API and
the frontend dropdowns all agree on the same options.

For v0.1 these are plain Python lists. Later they can become database
tables so the user can customize them (the handoff spec plans this for
transaction categories).
"""

ACCOUNT_TYPES = [
    "Checking",
    "Savings",
    "Cash",
    "Business Checking",
    "Brokerage",
    "Retirement",
    "Trading",
    "Other",
]

# Classification answers "what part of my financial life is this?"
# Accounts AND transactions use the same list.
ACCOUNT_CLASSIFICATIONS = [
    "Personal",
    "Business",
    "Investment",
    "Trading",
]

# Direction of a transaction. Amounts are always positive; the type says
# whether money came in (Income) or went out (Expense).
# "Transfer" is deliberately NOT here yet: a transfer touches two accounts
# and will be designed as its own slice (v0.2 handoff, section 8).
TRANSACTION_TYPES = [
    "Income",
    "Expense",
]

# Suggested categories from the v0.2 handoff (section 8). These are
# SUGGESTIONS shown in the form; the category field still accepts any text
# until categories become a customizable table.
TRANSACTION_CATEGORIES = [
    "Housing",
    "Insurance",
    "Education",
    "Subscriptions",
    "Utilities",
    "Transportation",
    "Car Maintenance",
    "Children",
    "Groceries",
    "Food",
    "Business Equipment",
    "Business Software",
    "Inventory",
    "Shipping",
    "Investment Contribution",
    "Dividend",
    "Trading Expense",
    "Other",
]

# Suggested categories for spending on a child (v0.3 handoff, section 5).
# Shown as suggestions when a dependent is chosen; any text is still allowed.
DEPENDENT_CATEGORIES = [
    "Food",
    "Clothing",
    "Medical",
    "Childcare",
    "Education",
    "Activities",
    "Supplies",
    "Other",
]

BILL_FREQUENCIES = [
    "Monthly",
    "Quarterly",
    "Annual",
    "One-time",
]

DEBT_TYPES = [
    "Credit Card",
    "Student Loan",
    "Personal Loan",
    "Mortgage",
    "Auto Loan",
    "Medical",
    "Other",
]
