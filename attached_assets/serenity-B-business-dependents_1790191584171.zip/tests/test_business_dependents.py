"""
Tests for Businesses, Dependents and their optional links from
transactions (Slice B).
"""

import pytest


def post(client, path, body):
    return client.post(f"/serenity-api/{path}", json=body)


def make_account(client, classification="Personal", balance="500.00"):
    response = post(client, "accounts", {
        "name": f"{classification} Checking", "account_type": "Checking",
        "classification": classification, "opening_balance": balance,
    })
    assert response.status_code == 201
    return response.json()


def record(client, account_id, **fields):
    body = {"date": "2026-09-23", "transaction_type": "Expense",
            "amount": "25.00", "description": "Test purchase", **fields}
    return client.post(f"/serenity-api/accounts/{account_id}/transactions", json=body)


# ---------------------------------------------------------------------------
# Businesses and dependents themselves
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("path,field", [("businesses", "name"), ("dependents", "display_name")])
def test_create_list_edit_deactivate(client, path, field):
    created = post(client, path, {field: "  KTT  ", "notes": ""})
    assert created.status_code == 201
    item = created.json()
    assert item[field] == "KTT"        # spaces trimmed
    assert item["notes"] is None        # blank becomes None
    assert item["active"] is True

    renamed = client.put(f"/serenity-api/{path}/{item['id']}", json={field: "KTT Media"})
    assert renamed.status_code == 200
    assert renamed.json()[field] == "KTT Media"

    assert client.post(f"/serenity-api/{path}/{item['id']}/deactivate").json()["active"] is False
    listed = client.get(f"/serenity-api/{path}").json()
    assert [(i[field], i["active"]) for i in listed] == [("KTT Media", False)]
    assert client.post(f"/serenity-api/{path}/{item['id']}/reactivate").json()["active"] is True


@pytest.mark.parametrize("path,field", [("businesses", "name"), ("dependents", "display_name")])
def test_names_are_unique_ignoring_capitals(client, path, field):
    first = post(client, path, {field: "Child 1"}).json()
    duplicate = post(client, path, {field: "child 1"})
    assert duplicate.status_code == 409
    assert "already exists" in duplicate.json()["detail"]

    other = post(client, path, {field: "Child 2"}).json()
    clash = client.put(f"/serenity-api/{path}/{other['id']}", json={field: "CHILD 1"})
    assert clash.status_code == 409
    # Renaming to your own name (different capitals) is fine.
    same = client.put(f"/serenity-api/{path}/{first['id']}", json={field: "CHILD 1"})
    assert same.status_code == 200


@pytest.mark.parametrize("path", ["businesses", "dependents"])
def test_unknown_ids_are_404(client, path):
    assert client.post(f"/serenity-api/{path}/999/deactivate").status_code == 404


def test_blank_names_are_rejected(client):
    assert post(client, "businesses", {"name": "   "}).status_code == 422
    assert post(client, "dependents", {"display_name": ""}).status_code == 422


# ---------------------------------------------------------------------------
# Linking transactions
# ---------------------------------------------------------------------------

def test_business_link_defaults_classification_to_business(client):
    """A KTT purchase paid from a PERSONAL account."""
    account = make_account(client, "Personal")
    ktt = post(client, "businesses", {"name": "KTT"}).json()

    response = record(client, account["id"], business_id=ktt["id"],
                      description="Replacement microphone for KTT content")
    assert response.status_code == 201
    body = response.json()
    assert body["classification"] == "Business"
    assert body["business_id"] == ktt["id"]
    assert body["business_name"] == "KTT"
    # The money still leaves the personal account; links don't change amounts.
    assert client.get(f"/serenity-api/accounts/{account['id']}").json()["current_balance"] == "475.00"


def test_business_link_with_other_classification_is_rejected(client):
    account = make_account(client)
    ktt = post(client, "businesses", {"name": "KTT"}).json()
    response = record(client, account["id"], business_id=ktt["id"], classification="Personal")
    assert response.status_code == 422
    assert "must be classified as Business" in response.json()["detail"]
    assert client.get(f"/serenity-api/accounts/{account['id']}/transactions").json() == []


def test_business_classification_without_a_business_is_allowed(client):
    account = make_account(client)
    response = record(client, account["id"], classification="Business")
    assert response.status_code == 201
    assert response.json()["business_id"] is None


def test_dependent_link_keeps_normal_classification(client):
    account = make_account(client)
    child = post(client, "dependents", {"display_name": "Child 1"}).json()
    body = record(client, account["id"], dependent_id=child["id"],
                  category="Clothing", description="Winter jacket").json()
    assert body["dependent_name"] == "Child 1"
    assert body["classification"] == "Personal"


def test_unknown_links_are_rejected(client):
    account = make_account(client)
    assert record(client, account["id"], business_id=999).status_code == 422
    assert record(client, account["id"], dependent_id=999).status_code == 422


def test_inactive_links_rejected_for_new_but_kept_on_edit(client):
    account = make_account(client)
    ktt = post(client, "businesses", {"name": "KTT"}).json()
    child = post(client, "dependents", {"display_name": "Child 1"}).json()
    linked = record(client, account["id"], business_id=ktt["id"], dependent_id=child["id"]).json()

    client.post(f"/serenity-api/businesses/{ktt['id']}/deactivate")
    client.post(f"/serenity-api/dependents/{child['id']}/deactivate")

    # New transactions can't use them...
    assert record(client, account["id"], business_id=ktt["id"]).status_code == 422
    assert record(client, account["id"], dependent_id=child["id"]).status_code == 422

    # ...but editing the existing transaction may keep the links.
    url = f"/serenity-api/accounts/{account['id']}/transactions/{linked['id']}"
    edited = client.put(url, json={
        "date": "2026-09-23", "transaction_type": "Expense", "amount": "30.00",
        "description": "Edited", "business_id": ktt["id"], "dependent_id": child["id"],
    })
    assert edited.status_code == 200
    assert edited.json()["business_name"] == "KTT"


def test_options_list_only_active_links(client):
    active = post(client, "businesses", {"name": "KTT"}).json()
    old = post(client, "businesses", {"name": "Old Venture"}).json()
    client.post(f"/serenity-api/businesses/{old['id']}/deactivate")
    post(client, "dependents", {"display_name": "Shared / All Children"})

    options = client.get("/serenity-api/transactions/options").json()
    assert options["businesses"] == [{"id": active["id"], "name": "KTT"}]
    assert [d["display_name"] for d in options["dependents"]] == ["Shared / All Children"]
    assert "Childcare" in options["dependent_categories"]


def test_history_keeps_names_from_the_time(client):
    """Renaming a business later must not rewrite what history says."""
    account = make_account(client)
    ktt = post(client, "businesses", {"name": "KTT"}).json()
    transaction = record(client, account["id"], business_id=ktt["id"]).json()
    url = f"/serenity-api/accounts/{account['id']}/transactions/{transaction['id']}"
    client.put(url, json={"date": "2026-09-23", "transaction_type": "Expense",
                          "amount": "25.00", "description": "Unlinked now"})
    client.put(f"/serenity-api/businesses/{ktt['id']}", json={"name": "KTT Media"})

    history = client.get(f"/serenity-api/accounts/{account['id']}/transaction-corrections").json()
    assert history[0]["before"]["business_name"] == "KTT"
    assert history[0]["after"]["business_name"] is None


def test_export_includes_businesses_dependents_and_links(client):
    account = make_account(client)
    ktt = post(client, "businesses", {"name": "KTT"}).json()
    child = post(client, "dependents", {"display_name": "Child 1"}).json()
    record(client, account["id"], business_id=ktt["id"], dependent_id=child["id"])

    backup = client.get("/serenity-api/export").json()
    assert backup["businesses"][0]["name"] == "KTT"
    assert backup["dependents"][0]["display_name"] == "Child 1"
    assert backup["transactions"][0]["business_id"] == ktt["id"]
    csv_text = client.get("/serenity-api/export/transactions.csv").text
    assert "KTT" in csv_text and "Child 1" in csv_text
