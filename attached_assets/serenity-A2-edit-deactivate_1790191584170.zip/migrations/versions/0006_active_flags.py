"""Add an `active` flag to bills, debts and investments.

Revision ID: 0006_active_flags
Revises: 0005_timezone_aware_timestamps

WHY
---
Serenity never hard-deletes financial records, because history matters.
Instead a record is DEACTIVATED: a paid-off debt, a cancelled
subscription, a sold investment. Accounts already had `active`; this adds
the same flag to bills, debts and investments.

`server_default=true` fills the new column for rows that already exist,
so every existing record starts out active. No data values change, so
this is safe with Replit Publish copying structure to production.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "0006_active_flags"
down_revision: Union[str, None] = "0005_timezone_aware_timestamps"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

TABLES = ["bills", "debts", "investments"]


def upgrade() -> None:
    for table in TABLES:
        with op.batch_alter_table(table) as batch:
            batch.add_column(
                sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true())
            )


def downgrade() -> None:
    for table in TABLES:
        with op.batch_alter_table(table) as batch:
            batch.drop_column("active")
