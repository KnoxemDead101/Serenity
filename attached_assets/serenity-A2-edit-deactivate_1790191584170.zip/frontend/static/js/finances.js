/*
 * Finances page: bills, debts and investments.
 *
 * All three sections work the same way:
 *   - the form ADDS a record, or SAVES an edit when "Edit" was clicked
 *   - each table row has Edit and Deactivate/Reactivate buttons
 *   - deactivated rows stay visible (greyed out) but stop counting in totals
 *
 * To avoid writing that logic three times, each section is described by a
 * small "config" object below, and setUpSection() wires it up.
 *
 * RULE: no calculations here. The server validates and calculates; this
 * file only reads forms and displays what the API returns.
 */

const financeApi = "/serenity-api";

function formatDate(dateString) {
  if (!dateString) return "—";
  return new Intl.DateTimeFormat("en-US", { dateStyle: "medium" }).format(
    new Date(`${dateString}T00:00:00`),
  );
}

function fillSelect(select, values) {
  select.replaceChildren();
  for (const value of values) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.appendChild(option);
  }
}

// ---------------------------------------------------------------------------
// The three sections
// ---------------------------------------------------------------------------
//   path      : API path, e.g. "bills"
//   noun      : word used in messages
//   columns   : how to turn one record into table cells (display only)
//   readForm  : how to turn the form into a request body
//   fillForm  : how to put a record back into the form for editing

const SECTIONS = [
  {
    path: "bills",
    noun: "Bill",
    form: "bill-form",
    body: "bills-body",
    message: "bill-message",
    columns: (bill) => [
      makeCell(bill.name),
      makeCell(formatDate(bill.due_date)),
      makeCell(bill.frequency),
      makeCell(bill.category || "—"),
      makeCell(formatMoney(bill.amount), "num"),
    ],
    readForm: (form) => ({
      name: form.elements.name.value,
      amount: form.elements.amount.value,
      due_date: form.elements.due_date.value,
      frequency: form.elements.frequency.value,
      category: form.elements.category.value,
    }),
    fillForm: (form, bill) => {
      form.elements.name.value = bill.name;
      form.elements.amount.value = bill.amount;
      form.elements.due_date.value = bill.due_date;
      form.elements.frequency.value = bill.frequency;
      form.elements.category.value = bill.category || "";
    },
  },
  {
    path: "debts",
    noun: "Debt",
    form: "debt-form",
    body: "debts-body",
    message: "debt-message",
    columns: (debt) => [
      makeCell(debt.name),
      makeCell(debt.debt_type),
      makeCell(formatDate(debt.due_date)),
      makeCell(`${debt.interest_rate}%`, "num"),
      makeCell(formatMoney(debt.minimum_payment), "num"),
      makeCell(formatMoney(debt.balance), "num"),
    ],
    readForm: (form) => ({
      name: form.elements.name.value,
      debt_type: form.elements.debt_type.value,
      balance: form.elements.balance.value,
      interest_rate: form.elements.interest_rate.value,
      minimum_payment: form.elements.minimum_payment.value,
      due_date: form.elements.due_date.value || null,
    }),
    fillForm: (form, debt) => {
      form.elements.name.value = debt.name;
      form.elements.debt_type.value = debt.debt_type;
      form.elements.balance.value = debt.balance;
      form.elements.interest_rate.value = debt.interest_rate;
      form.elements.minimum_payment.value = debt.minimum_payment;
      form.elements.due_date.value = debt.due_date || "";
    },
  },
  {
    path: "investments",
    noun: "Investment",
    form: "investment-form",
    body: "investments-body",
    message: "investment-message",
    columns: (investment) => [
      makeCell(investment.name),
      makeCell(investment.ticker || "—"),
      makeCell(investment.quantity, "num"),
      makeCell(formatMoney(investment.cost_basis), "num"),
      makeCell(formatMoney(investment.current_value), "num"),
    ],
    readForm: (form) => ({
      name: form.elements.name.value,
      ticker: form.elements.ticker.value,
      quantity: form.elements.quantity.value || "0",
      cost_basis: form.elements.cost_basis.value,
      current_value: form.elements.current_value.value,
    }),
    fillForm: (form, investment) => {
      form.elements.name.value = investment.name;
      form.elements.ticker.value = investment.ticker || "";
      form.elements.quantity.value = investment.quantity;
      form.elements.cost_basis.value = investment.cost_basis;
      form.elements.current_value.value = investment.current_value;
    },
  },
];

// ---------------------------------------------------------------------------
// Shared behavior for one section
// ---------------------------------------------------------------------------

function setUpSection(section) {
  const form = document.getElementById(section.form);
  const body = document.getElementById(section.body);
  const message = document.getElementById(section.message);
  const submit = form.querySelector('button[type="submit"]');
  const cancel = form.querySelector("[data-cancel]");
  const addLabel = submit.textContent;
  let records = [];
  let editingId = null;

  function resetForm() {
    editingId = null;
    form.reset();
    submit.textContent = addLabel;
    cancel.hidden = true;
  }

  function beginEdit(record) {
    editingId = record.id;
    section.fillForm(form, record);
    submit.textContent = `Save ${section.noun.toLowerCase()}`;
    cancel.hidden = false;
    form.elements.name.focus();
  }

  async function load() {
    records = await apiGet(`${financeApi}/${section.path}`);
    body.replaceChildren();
    const columnCount = form.closest("section").querySelectorAll("thead th").length;
    if (records.length === 0) {
      const row = document.createElement("tr");
      const cell = makeCell("No records yet.", "muted");
      cell.colSpan = columnCount;
      row.appendChild(cell);
      body.appendChild(row);
      return;
    }
    for (const record of records) {
      const row = document.createElement("tr");
      if (!record.active) row.className = "inactive";
      const cells = section.columns(record);
      if (!record.active) {
        const badge = document.createElement("span");
        badge.className = "badge";
        badge.textContent = "Inactive";
        cells[0].append(" ", badge);
      }
      row.append(...cells);
      row.appendChild(makeActionsCell(
        makeRowButton("Edit", "edit", record.id),
        record.active
          ? makeRowButton("Deactivate", "deactivate", record.id, "secondary")
          : makeRowButton("Reactivate", "reactivate", record.id, "secondary"),
      ));
      body.appendChild(row);
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const requestBody = section.readForm(form);
      if (editingId === null) {
        await apiPost(`${financeApi}/${section.path}`, requestBody);
        showMessage(message, `${section.noun} added.`, false);
      } else {
        await apiPut(`${financeApi}/${section.path}/${editingId}`, requestBody);
        showMessage(message, `${section.noun} saved.`, false);
      }
      resetForm();
      await load();
    } catch (error) {
      showMessage(message, error.message, true);
    }
  });

  cancel.addEventListener("click", resetForm);

  body.addEventListener("click", async (event) => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;
    const record = records.find((item) => item.id === Number(button.dataset.id));
    if (!record) return;
    if (button.dataset.action === "edit") {
      beginEdit(record);
      return;
    }
    if (button.dataset.action === "deactivate" && !window.confirm(
      `Deactivate "${record.name}"? It stays in your history but stops counting toward totals.`
    )) return;
    try {
      await apiPost(`${financeApi}/${section.path}/${record.id}/${button.dataset.action}`);
      showMessage(message,
        `${section.noun} ${button.dataset.action === "deactivate" ? "deactivated" : "reactivated"}.`,
        false);
      await load();
    } catch (error) {
      showMessage(message, error.message, true);
    }
  });

  return { load, resetForm };
}

// ---------------------------------------------------------------------------
// Page start-up
// ---------------------------------------------------------------------------

async function loadFinanceOptions() {
  const options = await apiGet(`${financeApi}/finance/options`);
  fillSelect(document.querySelector("#bill-form select[name=frequency]"), options.bill_frequencies);
  fillSelect(document.querySelector("#debt-form select[name=debt_type]"), options.debt_types);
}

const sections = SECTIONS.map(setUpSection);

loadFinanceOptions()
  .then(() => Promise.all(sections.map((section) => section.load())))
  .catch((error) => showMessage(document.getElementById("bill-message"), error.message, true));
