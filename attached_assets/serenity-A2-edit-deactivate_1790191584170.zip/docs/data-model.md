# Serenity Data Model

All tables have integer primary keys and time-zone-aware UTC
`created_at`/`updated_at` timestamps. The Alembic migrations are the
executable schema source of truth.

## Nothing is hard-deleted

Financial history is never erased. Records are **deactivated** instead
(`active = false`):

| Record | When deactivated… |
|---|---|
| Account | Hidden from the transaction form; **can't receive new transactions**; still counts toward total balance and net worth (its money still exists) |
| Bill | Leaves the monthly bill total and bill count (cancelled obligation) |
| Debt | Leaves total debt and net worth (closed / paid off; set the balance to 0 first) |
| Investment | Leaves investment value and net worth (sold) |
| Transaction | Soft-deleted with `deleted_at`, plus a correction-history snapshot |

Every record can be edited (`PUT`) and reactivated.

## accounts

An Account is an owned financial container. Credit cards are Debts.

| Column | Storage |
|---|---|
| `name` | text |
| `account_type` | checking, savings, cash, business checking, brokerage, retirement, trading, or other |
| `classification` | personal, business, investment, or trading display value |
| `opening_balance_cents` | integer cents |
| `institution` | optional text |
| `notes` | optional text |
| `active` | boolean |

Current balance is derived: opening balance + Income transactions − Expense
transactions (deleted transactions ignored). The sign of each transaction is
decided in one place: `services/transaction_service.signed_amount_cents()`.

## transactions

Financially meaningful money entering or leaving one account (v0.2 handoff,
section 8). Amounts are always positive; `transaction_type` controls the
direction.

| Column | Storage |
|---|---|
| `account_id` | foreign key to accounts |
| `date` | transaction date |
| `transaction_type` | Income or Expense (Transfer is deferred) |
| `classification` | Personal, Business, Investment, or Trading; defaults to the account's classification when not chosen |
| `amount_cents` | positive integer cents |
| `description` | required text: the reason money moved |
| `merchant` | optional text |
| `location` | optional text |
| `category` | optional text; suggestions come from `TRANSACTION_CATEGORIES` |
| `subcategory` | optional text |
| `created_at` / `updated_at` | UTC timestamps |
| `deleted_at` | optional UTC timestamp; set when removed from active history |

Active history is ordered by date descending, then ID descending.
Only transactions without `deleted_at` contribute to account and dashboard balances.

Account totals on the dashboard group by the **account's** classification
(where the money sits). A transaction's own classification records what the
money was *for*, e.g. a business purchase paid from a personal account.

Migration `0004_align_transactions_v02` renamed existing `Deposit` rows to
`Income` and `Withdrawal` rows to `Expense`, and copied each account's
classification onto its existing transactions.

## transaction_corrections

Each edit and deletion records an append-only snapshot of the prior transaction,
in the same commit as the change. Edits also record the resulting state; deletions
retain the transaction row with `deleted_at` set but remove it from active history.
The corrections list is read-only through the application API.

| Column | Storage |
|---|---|
| `account_id` | foreign key to accounts, for account-scoped history |
| `transaction_id` | foreign key to the retained transaction row |
| `action` | Updated or Deleted |
| `changed_at` | UTC timestamp |
| `before` | JSON snapshot: date, type, classification, integer amount cents, description, merchant, location, category, subcategory |
| `after` | JSON snapshot after an edit; null for a deletion |

History is never rewritten. Snapshots saved before migration 0004 still say
`Deposit`/`Withdrawal` and lack the newer keys; the API fills those with null.

## bills

A Bill is an obligation, not proof that payment occurred.

| Column | Storage |
|---|---|
| `name` | text |
| `amount_cents` | non-negative integer cents |
| `due_date` | date |
| `frequency` | monthly, quarterly, annual, or one-time display value |
| `category` | optional text |
| `notes` | optional text |
| `active` | boolean, default true |

One-time bills are excluded from recurring monthly totals.

## debts

Debts include credit cards, student loans, personal loans, mortgages, auto
loans, medical debt, and other liabilities.

| Column | Storage |
|---|---|
| `name` | text |
| `debt_type` | validated debt type |
| `balance_cents` | non-negative integer cents |
| `interest_rate_milli` | thousandths of a percent |
| `minimum_payment_cents` | non-negative integer cents |
| `due_date` | optional date |
| `notes` | optional text |
| `active` | boolean, default true |

For example, `6.875%` is stored as `6875`.

## investments

The current Investment model is a retained starting-position feature. The
future Portfolio milestone will replace direct cost-basis and current-value
entry with Holdings and Investment Transactions.

| Column | Storage |
|---|---|
| `name` | text |
| `ticker` | optional text |
| `quantity_units` | integer, eight decimal places |
| `cost_basis_cents` | non-negative integer cents |
| `current_value_cents` | non-negative integer cents |
| `notes` | optional text |
| `active` | boolean, default true |

For example, `0.12345678` units is stored as `12,345,678`.

**Until the Portfolio milestone:** a Brokerage or Retirement account's opening
balance should be its *cash only*; holdings are entered as Investments.
Otherwise net worth counts the same money twice.
