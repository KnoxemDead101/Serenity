"""
Tests for editing and deactivating accounts, bills, debts and investments
(Slice A2). Nothing is ever hard-deleted.
"""

import pytest

ACCOUNT = {
    "name": "Checking", "account_type": "Checking",
    "classification": "Personal", "opening_balance": "100.00",
}
BILL = {"name": "Rent", "amount": "1200.00", "due_date": "2026-10-01", "frequency": "Monthly"}
DEBT = {"name": "Card", "debt_type": "Credit Card", "balance": "500.00",
        "interest_rate": "6.875", "minimum_payment": "25.00"}
INVESTMENT = {"name": "Index fund", "ticker": "vti", "quantity": "2.5",
              "cost_basis": "400.00", "current_value": "450.00"}


def create(client, path, body):
    response = client.post(f"/serenity-api/{path}", json=body)
    assert response.status_code == 201, response.text
    return response.json()


def summary(client):
    return client.get("/serenity-api/dashboard/summary").json()


# ---------------------------------------------------------------------------
# Accounts
# ---------------------------------------------------------------------------

def test_edit_account_changes_details_and_recalculates_balance(client):
    account = create(client, "accounts", ACCOUNT)
    client.post(f"/serenity-api/accounts/{account['id']}/transactions", json={
        "date": "2026-09-23", "transaction_type": "Expense",
        "amount": "10.00", "description": "Groceries",
    })
    response = client.put(f"/serenity-api/accounts/{account['id']}", json={
        **ACCOUNT, "name": " Everyday Checking ", "opening_balance": "150.00",
        "institution": "Desert Financial",
    })
    assert response.status_code == 200
    body = response.json()
    assert body["name"] == "Everyday Checking"
    assert body["institution"] == "Desert Financial"
    # Current balance is recalculated from the new opening balance.
    assert body["current_balance"] == "140.00"


def test_edit_account_validates_like_create(client):
    account = create(client, "accounts", ACCOUNT)
    bad = client.put(f"/serenity-api/accounts/{account['id']}",
                     json={**ACCOUNT, "account_type": "Piggy Bank"})
    assert bad.status_code == 422
    assert client.put("/serenity-api/accounts/999", json=ACCOUNT).status_code == 404


def test_deactivated_account_still_counts_but_rejects_new_transactions(client):
    account = create(client, "accounts", ACCOUNT)
    url = f"/serenity-api/accounts/{account['id']}"

    deactivated = client.post(f"{url}/deactivate")
    assert deactivated.status_code == 200
    assert deactivated.json()["active"] is False

    # Its money still exists, so it still counts.
    assert summary(client)["total_balance"] == "100.00"
    assert summary(client)["net_worth"] == "100.00"

    blocked = client.post(f"{url}/transactions", json={
        "date": "2026-09-23", "transaction_type": "Income",
        "amount": "5.00", "description": "Should be refused",
    })
    assert blocked.status_code == 422
    assert "deactivated" in blocked.json()["detail"]

    assert client.post(f"{url}/reactivate").json()["active"] is True
    allowed = client.post(f"{url}/transactions", json={
        "date": "2026-09-23", "transaction_type": "Income",
        "amount": "5.00", "description": "Now allowed",
    })
    assert allowed.status_code == 201


def test_deactivate_unknown_account_is_404(client):
    assert client.post("/serenity-api/accounts/999/deactivate").status_code == 404


# ---------------------------------------------------------------------------
# Bills, debts, investments
# ---------------------------------------------------------------------------

def test_edit_bill(client):
    bill = create(client, "bills", BILL)
    response = client.put(f"/serenity-api/bills/{bill['id']}",
                          json={**BILL, "amount": "300.00", "frequency": "Quarterly"})
    assert response.status_code == 200
    assert response.json()["amount"] == "300.00"
    assert summary(client)["monthly_bill_total"] == "100.00"


def test_edit_debt_keeps_precise_rate(client):
    debt = create(client, "debts", DEBT)
    response = client.put(f"/serenity-api/debts/{debt['id']}",
                          json={**DEBT, "balance": "450.00", "interest_rate": "7.125"})
    assert response.status_code == 200
    assert response.json()["balance"] == "450.00"
    assert response.json()["interest_rate"] == "7.125"


def test_edit_investment_uppercases_ticker(client):
    investment = create(client, "investments", INVESTMENT)
    response = client.put(f"/serenity-api/investments/{investment['id']}",
                          json={**INVESTMENT, "ticker": "voo", "current_value": "475.25"})
    assert response.status_code == 200
    assert response.json()["ticker"] == "VOO"
    assert response.json()["current_value"] == "475.25"


@pytest.mark.parametrize("path,body,count_field,total_field,total_before", [
    ("bills", BILL, "bill_count", "monthly_bill_total", "1200.00"),
    ("debts", DEBT, "debt_count", "debt_balance", "500.00"),
    ("investments", INVESTMENT, "investment_count", "investment_value", "450.00"),
])
def test_deactivated_finance_records_leave_totals(client, path, body, count_field,
                                                  total_field, total_before):
    record = create(client, path, body)
    assert record["active"] is True
    assert summary(client)[count_field] == 1
    assert summary(client)[total_field] == total_before

    response = client.post(f"/serenity-api/{path}/{record['id']}/deactivate")
    assert response.status_code == 200
    assert response.json()["active"] is False
    assert summary(client)[count_field] == 0
    assert summary(client)[total_field] == "0.00"
    # Still listed, for history.
    assert [item["active"] for item in client.get(f"/serenity-api/{path}").json()] == [False]

    client.post(f"/serenity-api/{path}/{record['id']}/reactivate")
    assert summary(client)[total_field] == total_before


def test_net_worth_ignores_deactivated_debt_and_investment(client):
    create(client, "accounts", ACCOUNT)                   # +100.00
    debt = create(client, "debts", DEBT)                  # -500.00
    investment = create(client, "investments", INVESTMENT)  # +450.00
    assert summary(client)["net_worth"] == "50.00"

    client.post(f"/serenity-api/debts/{debt['id']}/deactivate")
    assert summary(client)["net_worth"] == "550.00"
    client.post(f"/serenity-api/investments/{investment['id']}/deactivate")
    assert summary(client)["net_worth"] == "100.00"


@pytest.mark.parametrize("path", ["bills", "debts", "investments"])
def test_unknown_finance_records_are_404(client, path):
    assert client.put(f"/serenity-api/{path}/999", json={}).status_code in (404, 422)
    assert client.post(f"/serenity-api/{path}/999/deactivate").status_code == 404
    assert client.post(f"/serenity-api/{path}/999/reactivate").status_code == 404
