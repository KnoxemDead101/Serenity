/*
 * Shared helpers for talking to the Serenity backend.
 *
 * RULE: JavaScript in Serenity only fetches and displays data.
 * All financial calculations happen in Python (services/).
 */

// Send a GET request and return the parsed JSON.
async function apiGet(url) {
  const response = await fetch(url);
  return handleResponse(response);
}

// Send a POST request with a JSON body and return the parsed JSON.
async function apiPost(url, body = {}) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return handleResponse(response);
}

async function apiPut(url, body) {
  const response = await fetch(url, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return handleResponse(response);
}

async function apiDelete(url) {
  const response = await fetch(url, { method: "DELETE" });
  return handleResponse(response);
}

// If the server reports an error, turn it into a readable message.
//
// HTTP 401 means "you are not signed in" - usually because the 12-hour
// Serenity session expired while this page was open. Instead of showing a
// confusing error, send the person to the sign-in page and bring them back
// to this same page afterwards (?next=...). auth.js only accepts a `next`
// that points back inside Serenity, so this can't be abused as a redirect.
async function handleResponse(response) {
  if (response.status === 401) {
    redirectToSignIn();
    throw new Error("Your session has ended. Redirecting to sign in...");
  }
  const data = await response.json().catch(() => null);
  if (response.ok) {
    return data;
  }
  throw new Error(describeError(data, response.status));
}

function redirectToSignIn() {
  const here = window.location.pathname + window.location.search;
  window.location.assign(`/sign-in?next=${encodeURIComponent(here)}`);
}

// FastAPI validation errors (HTTP 422) look like:
//   { "detail": [ { "loc": [...], "msg": "Value error, Name is required" } ] }
// Other errors look like: { "detail": "Account not found" }
function describeError(data, status) {
  if (data && Array.isArray(data.detail)) {
    return data.detail
      .map((problem) => problem.msg.replace(/^Value error, /, ""))
      .join(". ");
  }
  if (data && typeof data.detail === "string") {
    return data.detail;
  }
  return `Request failed (HTTP ${status})`;
}

// Display only: the API sends money as strings like "1234.50".
// Formatting it as "$1,234.50" is presentation, not calculation.
function formatMoney(amountString) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(Number(amountString));
}

// Build a table cell safely. Using textContent (not innerHTML) means
// text typed by the user can never be run as HTML/JavaScript.
function makeCell(text, className) {
  const cell = document.createElement("td");
  cell.textContent = text;
  if (className) {
    cell.className = className;
  }
  return cell;
}

function makeRowButton(label, action, id, className) {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = label;
  button.dataset.action = action;
  button.dataset.id = String(id);
  if (className) button.className = className;
  return button;
}

function makeActionsCell(...buttons) {
  const cell = document.createElement("td");
  const group = document.createElement("div");
  group.className = "row-actions";
  group.append(...buttons);
  cell.appendChild(group);
  return cell;
}

function showMessage(target, text, isError) {
  target.textContent = text;
  target.className = isError ? "message error" : "message success";
  target.hidden = false;
}

// Mobile navigation. On narrow screens the CSS hides the page links behind
// a "Menu" button; this only opens/closes that menu (no data, no maths).
// aria-expanded tells screen readers whether the menu is open.
function setupNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const topbar = document.querySelector(".topbar");
  if (!toggle || !topbar) return;
  toggle.addEventListener("click", () => {
    const open = topbar.classList.toggle("nav-open");
    toggle.setAttribute("aria-expanded", String(open));
  });
  // Escape closes the menu, like most menus.
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && topbar.classList.contains("nav-open")) {
      topbar.classList.remove("nav-open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.focus();
    }
  });
}

document.addEventListener("DOMContentLoaded", setupNavToggle);
