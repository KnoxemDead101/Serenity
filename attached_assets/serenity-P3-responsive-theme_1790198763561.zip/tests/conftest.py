"""
Shared test setup (pytest loads this file automatically).

DATABASE
--------
Every test gets a brand-new, EMPTY database that lives only in memory, so
tests never touch serenity.db or PostgreSQL and can't affect each other.

AUTHENTICATION
--------------
Production code has no "test user" shortcut. Instead, the `client` fixture
uses FastAPI's dependency_overrides to replace the two sign-in checks with
a function that returns TEST_OWNER_ID. Every record the tests create is
therefore owned, explicitly, by "test-owner".

Tests that need REAL cookie authentication (sign-in redirects, two users
seeing only their own data) use the `real_auth_client` fixture, which
removes those overrides again. Use `sign_in_as(client, "owner-a")` to
switch users.
"""

import os

if os.getenv("DATABASE_URL", "").startswith("postgresql"):
    os.environ["DATABASE_URL"] = "sqlite://"
os.environ.setdefault("SESSION_SECRET", "test-session-secret")

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import models.account  # noqa: F401  (registers the accounts table)
import models.bill  # noqa: F401
import models.business  # noqa: F401
import models.debt  # noqa: F401
import models.dependent  # noqa: F401
import models.investment  # noqa: F401
import models.transaction  # noqa: F401
import models.transaction_correction  # noqa: F401
from auth import AUTH_COOKIE, issue_session, require_page_session, require_session
from main import app
from storage.database import Base, get_db

# The explicit owner used by ordinary tests (and by service-level tests
# that call services directly with owner_id=TEST_OWNER_ID).
TEST_OWNER_ID = "test-owner"


@pytest.fixture
def db():
    """A database session connected to a fresh in-memory SQLite database."""
    engine = create_engine(
        "sqlite://",  # no file name = in memory
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,  # every connection shares the same memory DB
    )
    Base.metadata.create_all(bind=engine)
    TestingSession = sessionmaker(bind=engine, autoflush=False)
    session = TestingSession()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()


@pytest.fixture
def client(db):
    """
    A fake browser that calls the API without starting a real server,
    signed in as TEST_OWNER_ID and using the in-memory test database.
    """
    app.dependency_overrides[get_db] = lambda: db
    app.dependency_overrides[require_session] = lambda: TEST_OWNER_ID
    app.dependency_overrides[require_page_session] = lambda: TEST_OWNER_ID
    yield TestClient(app)
    app.dependency_overrides.clear()


@pytest.fixture
def real_auth_client(client):
    """
    Same client, but with REAL cookie authentication: no one is signed in
    until a test calls sign_in_as().
    """
    app.dependency_overrides.pop(require_session, None)
    app.dependency_overrides.pop(require_page_session, None)
    client.cookies.clear()
    yield client


def sign_in_as(client, user_id: str) -> None:
    """Give the client a valid signed Serenity session cookie for user_id."""
    client.cookies.set(AUTH_COOKIE, issue_session(user_id))


# ---------------------------------------------------------------------------
# Browser tests (Playwright + Chromium)
# ---------------------------------------------------------------------------
# The real HTML/JS pages run in headless Chromium. Every request the page
# makes is answered by the in-memory test app above (no server, no network).
#
# If Chromium or Playwright isn't installed, browser tests are SKIPPED with
# a clear reason instead of failing the whole run. Set
# SERENITY_REQUIRE_BROWSER=1 (e.g. in the pre-publish check) to turn a
# missing browser into a failure instead.

def _find_chromium() -> str | None:
    import shutil

    for name in ("chromium", "chromium-browser", "google-chrome"):
        path = shutil.which(name)
        if path:
            return path
    return None


def _browser_unavailable(reason: str) -> None:
    if os.getenv("SERENITY_REQUIRE_BROWSER") == "1":
        pytest.fail(reason)
    pytest.skip(reason)


@pytest.fixture
def page(client):
    """A Chromium page whose requests are served by the test app."""
    from urllib.parse import urlsplit

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        _browser_unavailable("Playwright is not installed")
    executable = _find_chromium()
    if executable is None:
        _browser_unavailable("Chromium is not installed")

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=executable, headless=True, args=["--no-sandbox"]
        )
        page = browser.new_page()
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))

        def dispatch(route):
            request = route.request
            parts = urlsplit(request.url)
            path = parts.path + (f"?{parts.query}" if parts.query else "")
            response = client.request(
                request.method,
                path,
                content=request.post_data_buffer,
                headers={"content-type": request.headers.get("content-type", "")},
            )
            route.fulfill(
                status=response.status_code,
                body=response.content,
                headers={"content-type": response.headers.get("content-type", "text/plain")},
            )

        page.route("**/*", dispatch)
        try:
            yield page
            assert errors == [], f"Uncaught browser errors: {errors}"
        finally:
            browser.close()
