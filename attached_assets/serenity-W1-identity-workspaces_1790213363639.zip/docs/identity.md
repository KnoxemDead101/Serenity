# Identity and Workspaces (migration 0011)

## Why this exists

Before 0011, every financial record's `owner_id` held the **Clerk user id**. That tied
your money data to one sign-in provider: a new Clerk instance, or leaving Clerk, would
produce new ids and orphan every record.

Since 0011, Serenity has its own identity layer, and records belong to a **workspace**.

```
Browser ──Clerk sign-in──► Clerk
   │
   │ POST /serenity-api/auth/session  (Clerk token)
   ▼
auth.verify_clerk_token()      signature, claims, live session check
   │  (issuer, subject)
   ▼
services/identity_service.py
   AuthIdentity (provider, issuer, subject) ──► SerenityUser ◄── Workspace
                                                                     │
   every financial table: owner_id = Workspace.id  ◄─────────────────┘
```

| Table | One row means | Key facts |
|---|---|---|
| `users` | a person, in Serenity's own terms | UUID id, `active` flag |
| `workspaces` | that person's financial data container | UUID id, exactly one per user today (unique `owner_user_id`) |
| `auth_identities` | one external login that maps to a user | unique `(provider, issuer, subject)`, `last_sign_in_at` |

**No email is stored.** Ownership is keyed on the Clerk instance (`issuer`) and Clerk's
user id (`subject`). Changing your email or password in Clerk changes neither, so it can
never move or orphan your data.

## Request flow

1. `current_user()` verifies the cookie and asks Clerk if the session is still live.
2. `require_session()` / `require_page_session()` call `identity_service.workspace_for_identity()`.
3. The first time a verified identity appears, the service creates user + workspace +
   identity **in one transaction**. Later requests just look it up (one indexed query).
4. Routes receive the **workspace id** and pass it to services as `owner_id`.
   Services filter every query with `WHERE owner_id = <workspace id>` (unchanged code).

Results by situation:

| Situation | Result |
|---|---|
| Not signed in / cookie invalid / Clerk revoked or unreachable | 401 (API) or redirect to sign-in (page) |
| Serenity user deactivated | 403, including at sign-in (no cookie issued) |
| `CLERK_PUBLISHABLE_KEY` missing on the server | 503: we can't tell which Clerk instance vouched for the user |

## Invites: Clerk is the gate

Anyone Clerk lets sign in gets a workspace automatically. **Keep the Clerk dashboard in
Restricted (invite-only) sign-up mode.** Invited users get an empty, isolated workspace.

## Two deliberate design choices

- **`owner_id` kept its name.** Its value is now a workspace id. Renaming the column would
  touch ~30 files, and after real data exists, Replit Publish may treat a rename as
  "drop + add column", which would lose data. Rule: never rename a populated column.
- **No database foreign keys from financial tables to `workspaces`.** On SQLite, adding
  them rebuilds every table, which silently drops the case-insensitive name indexes on
  businesses/dependents (see migration 0008). The service layer, owner-isolation tests
  and `scripts/check_production_rows.py` (which reports rows not in a workspace) enforce
  the link instead.

## Administrator tasks (Replit Shell, Python)

Deactivate a user (their data is kept; every request gets 403):

```python
from storage.database import SessionLocal
from services import identity_service
db = SessionLocal()
identity_service.set_user_active(db, "<users.id>", False)
```

Find a user id: `SELECT u.id, i.subject, i.last_sign_in_at FROM users u JOIN auth_identities i ON i.user_id = u.id;`
(The subject is the Clerk user id shown in the Clerk dashboard.)

## Moving to a new Clerk instance or provider (future)

A new instance has a different `issuer`, so the first sign-in creates a **new, empty**
workspace. Linking it to the old user is a future admin tool: point the new
`auth_identities` row at the old `user_id` and remove the empty user/workspace. Never
link identities by matching emails.

## Migration 0011 notes

- Creates the three tables, then moves each existing Clerk owner into its own
  user + workspace + identity, rewriting `owner_id`. Downgrade restores the Clerk ids.
- It derives `issuer` from `CLERK_PUBLISHABLE_KEY`. **Run it where that key is set**
  (the Replit Shell has it). Without the key, existing rows get issuer `unconfigured` and
  won't match a sign-in until relinked.
- Production never runs Alembic. Publish copies the new tables' structure; production
  had no rows, so no data step is needed there. Run `check_production_rows.py` first
  and confirm `RESULT: no financial rows.`
