"""The pre-publish check also catches rows whose owner is not a workspace (0011+)."""

import sqlite3

from test_migrations import run_alembic
from test_production_check import run_check


def test_checker_flags_rows_not_linked_to_a_workspace(tmp_path):
    path = tmp_path / "orphan.db"
    run_alembic(path, "upgrade", "head")
    connection = sqlite3.connect(path)
    connection.execute(
        "INSERT INTO accounts (id, owner_id, name, account_type, classification, "
        "opening_balance_cents, active, created_at, updated_at) "
        "VALUES (1, 'user_raw_clerk_id', 'Secret Savings', 'Savings', 'Personal', "
        "99999, 1, '2026-09-23 12:00:00', '2026-09-23 12:00:00')"
    )
    connection.commit()
    connection.close()
    result = run_check(path)
    assert result.returncode == 1
    assert "not linked to a workspace" in result.stdout
    assert "Secret Savings" not in result.stdout
    assert "user_raw_clerk_id" not in result.stdout


def test_checker_accepts_rows_owned_by_a_real_workspace(tmp_path):
    path = tmp_path / "linked.db"
    run_alembic(path, "upgrade", "head")
    connection = sqlite3.connect(path)
    now = "2026-09-23 12:00:00"
    connection.execute("INSERT INTO users (id, active, created_at) VALUES ('u1', 1, ?)", (now,))
    connection.execute(
        "INSERT INTO workspaces (id, owner_user_id, name, created_at) "
        "VALUES ('w1', 'u1', 'Primary', ?)", (now,))
    connection.execute(
        "INSERT INTO accounts (id, owner_id, name, account_type, classification, "
        "opening_balance_cents, active, created_at, updated_at) "
        "VALUES (1, 'w1', 'Checking', 'Checking', 'Personal', 0, 1, ?, ?)", (now, now))
    connection.commit()
    connection.close()
    result = run_check(path)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "every row has an owner" in result.stdout
