"""
Internal identity: Clerk login -> AuthIdentity -> SerenityUser -> Workspace.

These tests use real_auth_client, so the real chain runs:
cookie -> (fixture) Clerk session check -> identity_service -> workspace id.
"""

import pytest
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from conftest import TEST_CLERK_ISSUER, sign_in_as
from models.account import Account
from models.identity import AuthIdentity, SerenityUser, Workspace
from services import identity_service
from test_clerk_handoff import ISSUER, clerk, exchange  # noqa: F401  (fixture)

NEW_ACCOUNT = {
    "name": "Checking", "account_type": "Checking",
    "classification": "Personal", "opening_balance": "10.00",
}


def _count(db, model) -> int:
    return db.scalar(select(func.count()).select_from(model))


def test_first_request_provisions_exactly_one_user_workspace_and_identity(real_auth_client, db):
    sign_in_as(real_auth_client, "clerk-user-a")
    assert real_auth_client.get("/serenity-api/accounts").status_code == 200
    assert real_auth_client.get("/serenity-api/accounts").status_code == 200
    assert real_auth_client.get("/").status_code == 200

    assert (_count(db, SerenityUser), _count(db, Workspace), _count(db, AuthIdentity)) == (1, 1, 1)
    identity = db.scalars(select(AuthIdentity)).one()
    assert (identity.provider, identity.issuer, identity.subject) == (
        "clerk", TEST_CLERK_ISSUER, "clerk-user-a",
    )
    workspace = db.scalars(select(Workspace)).one()
    assert workspace.owner_user_id == identity.user_id
    assert workspace.name == "Primary"


def test_records_are_owned_by_the_workspace_not_the_clerk_id(real_auth_client, db):
    sign_in_as(real_auth_client, "clerk-user-a")
    created = real_auth_client.post("/serenity-api/accounts", json=NEW_ACCOUNT)
    assert created.status_code == 201
    workspace = db.scalars(select(Workspace)).one()
    account = db.get(Account, created.json()["id"])
    assert account.owner_id == workspace.id
    assert account.owner_id != "clerk-user-a"


def test_two_clerk_users_get_two_isolated_workspaces(real_auth_client, db):
    sign_in_as(real_auth_client, "clerk-user-a")
    account_id = real_auth_client.post("/serenity-api/accounts", json=NEW_ACCOUNT).json()["id"]
    sign_in_as(real_auth_client, "clerk-user-b")
    assert real_auth_client.get("/serenity-api/accounts").json() == []
    assert real_auth_client.get(f"/serenity-api/accounts/{account_id}").status_code == 404
    assert _count(db, Workspace) == 2


def test_same_subject_from_another_clerk_instance_is_a_different_identity(db):
    first = identity_service.workspace_for_identity(
        db, provider="clerk", issuer="https://old.clerk.example", subject="user_1",
    )
    second = identity_service.workspace_for_identity(
        db, provider="clerk", issuer="https://new.clerk.example", subject="user_1",
    )
    assert first != second


def test_repeat_lookup_is_stable_and_duplicates_are_blocked(db):
    first = identity_service.workspace_for_identity(
        db, provider="clerk", issuer=TEST_CLERK_ISSUER, subject="user_1",
    )
    again = identity_service.workspace_for_identity(
        db, provider="clerk", issuer=TEST_CLERK_ISSUER, subject="user_1",
    )
    assert first == again
    user_id = db.scalars(select(SerenityUser.id)).one()
    db.add(AuthIdentity(
        user_id=user_id, provider="clerk", issuer=TEST_CLERK_ISSUER, subject="user_1",
    ))
    with pytest.raises(IntegrityError):
        db.commit()
    db.rollback()


@pytest.mark.parametrize("provider,issuer,subject", [
    ("clerk", TEST_CLERK_ISSUER, ""),
    ("clerk", "   ", "user_1"),
    (None, TEST_CLERK_ISSUER, "user_1"),
    ("clerk", TEST_CLERK_ISSUER, "x" * 256),
])
def test_missing_or_oversized_identity_parts_never_get_a_workspace(db, provider, issuer, subject):
    with pytest.raises(identity_service.IdentityError):
        identity_service.workspace_for_identity(
            db, provider=provider, issuer=issuer, subject=subject,
        )
    assert _count(db, Workspace) == 0


def test_deactivated_user_is_refused_everywhere_and_data_is_kept(real_auth_client, db):
    sign_in_as(real_auth_client, "clerk-user-a")
    assert real_auth_client.post("/serenity-api/accounts", json=NEW_ACCOUNT).status_code == 201
    user_id = db.scalars(select(SerenityUser.id)).one()
    identity_service.set_user_active(db, user_id, False)

    assert real_auth_client.get("/serenity-api/accounts").status_code == 403
    assert real_auth_client.get("/serenity-api/export").status_code == 403
    assert real_auth_client.post("/serenity-api/accounts", json=NEW_ACCOUNT).status_code == 403
    assert real_auth_client.get("/", follow_redirects=False).status_code == 403
    assert _count(db, Account) == 1  # deactivation never deletes

    identity_service.set_user_active(db, user_id, True)
    assert len(real_auth_client.get("/serenity-api/accounts").json()) == 1


def test_missing_clerk_configuration_fails_closed(real_auth_client, monkeypatch, db):
    monkeypatch.delenv("CLERK_PUBLISHABLE_KEY")
    sign_in_as(real_auth_client, "clerk-user-a")
    assert real_auth_client.get("/serenity-api/accounts").status_code == 503
    assert _count(db, Workspace) == 0


def test_last_sign_in_is_recorded_only_when_asked(db):
    identity_service.workspace_for_identity(
        db, provider="clerk", issuer=TEST_CLERK_ISSUER, subject="quiet",
    )
    identity_service.workspace_for_identity(
        db, provider="clerk", issuer=TEST_CLERK_ISSUER, subject="signed-in",
        record_sign_in=True,
    )
    stamps = dict(db.execute(select(AuthIdentity.subject, AuthIdentity.last_sign_in_at)).all())
    assert stamps["quiet"] is None
    assert stamps["signed-in"] is not None


def test_session_exchange_provisions_the_workspace_and_records_sign_in(real_auth_client, clerk, db):
    real_auth_client.base_url = "https://testserver"
    assert exchange(real_auth_client, clerk["token"]()).status_code == 200
    identity = db.scalars(select(AuthIdentity)).one()
    assert (identity.issuer, identity.subject) == (ISSUER, "user-test")
    assert identity.last_sign_in_at is not None


def test_deactivated_user_cannot_mint_a_new_session_cookie(real_auth_client, clerk, db):
    real_auth_client.base_url = "https://testserver"
    assert exchange(real_auth_client, clerk["token"]()).status_code == 200
    user_id = db.scalars(select(SerenityUser.id)).one()
    identity_service.set_user_active(db, user_id, False)
    real_auth_client.cookies.clear()
    response = exchange(real_auth_client, clerk["token"]())
    assert response.status_code == 403
    assert "set-cookie" not in response.headers


def test_auth_me_still_reports_the_clerk_user(real_auth_client):
    sign_in_as(real_auth_client, "clerk-user-a")
    assert real_auth_client.get("/serenity-api/auth/me").json() == {"user_id": "clerk-user-a"}

