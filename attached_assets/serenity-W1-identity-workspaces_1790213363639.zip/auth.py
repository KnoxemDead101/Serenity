"""
Authentication helpers for the Serenity web application.

THE SIGN-IN FLOW
----------------
1. The browser signs in with Clerk (sign-in.html + static/js/auth.js).
2. The browser sends Clerk's short-lived session token to
   POST /serenity-api/auth/session.
3. verify_clerk_token() checks the token's RSA signature and claims, then
   asks Clerk's API whether that session is still active.
4. Serenity sets its own cookie (`serenity_session`): HMAC-signed, HttpOnly,
   12 hours, bound to that Clerk session id.
5. On EVERY protected request, current_user() re-verifies the cookie and asks
   Clerk again whether the session is still active. Signing out or revoking
   a session in Clerk therefore takes effect immediately.
6. require_session() then turns the verified Clerk user into a Serenity
   WORKSPACE id (services/identity_service.py). That workspace id is what
   routes pass to services as `owner_id`.

WHAT EACH DEPENDENCY RETURNS
----------------------------
current_user(request)        -> Clerk user id (or None). Identity only.
require_session(...)         -> workspace id, or 401 / 403 / 503. For APIs.
require_page_session(...)    -> workspace id, or a redirect to /sign-in. For pages.

FAILING CLOSED
--------------
Every failure path (bad signature, expired cookie, Clerk unreachable,
session revoked, user mismatch, deactivated Serenity user, missing
configuration) denies access. Nothing falls back to a default user.

Cost to know about: step 5 makes one HTTPS call to api.clerk.com per request
(cached for the rest of that request). If Clerk is slow or down, Serenity is
unavailable. That is the price of instant revocation.
"""

import base64
import hashlib
import hmac
import json
import logging
import os
import re
import time
import urllib.error
import urllib.request
from functools import lru_cache
from typing import Any
from urllib.parse import quote

import jwt
from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from services import identity_service
from storage.database import get_db

AUTH_COOKIE = "serenity_session"
SESSION_TTL_SECONDS = 60 * 60 * 12

# Clerk ids and session ids are simple tokens. Anything else is refused,
# which also stops values like "../other" reaching Clerk's API URL.
_SAFE_ID = re.compile(r"[A-Za-z0-9_-]+")


# --- Serenity's own session cookie -------------------------------------------

def _secret() -> bytes:
    """The HMAC key for cookies. Refuse to run without one."""
    secret = os.getenv("SESSION_SECRET")
    if not secret:
        raise RuntimeError("SESSION_SECRET must be configured")
    return secret.encode("utf-8")


def _encode(value: dict[str, Any]) -> str:
    """JSON payload + HMAC-SHA256 signature, both base64url: 'payload.signature'."""
    payload = base64.urlsafe_b64encode(
        json.dumps(value, separators=(",", ":")).encode("utf-8")
    ).rstrip(b"=").decode("ascii")
    signature = hmac.new(_secret(), payload.encode("ascii"), hashlib.sha256).digest()
    encoded_signature = base64.urlsafe_b64encode(signature).rstrip(b"=").decode("ascii")
    return f"{payload}.{encoded_signature}"


def _decode(value: str) -> dict[str, Any] | None:
    """Return the cookie payload only if the signature, expiry and fields are valid."""
    try:
        payload, signature = value.split(".", 1)
        expected = hmac.new(_secret(), payload.encode("ascii"), hashlib.sha256).digest()
        supplied = base64.urlsafe_b64decode(signature + "=" * (-len(signature) % 4))
        # compare_digest takes the same time whether or not bytes match,
        # so an attacker can't learn the signature one byte at a time.
        if not hmac.compare_digest(expected, supplied):
            return None
        decoded = base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4))
        session = json.loads(decoded)
        if not isinstance(session, dict) or session.get("expires_at", 0) < time.time():
            return None
        if not isinstance(session.get("user_id"), str) or not session["user_id"]:
            return None
        if not isinstance(session.get("clerk_session_id"), str) or not _SAFE_ID.fullmatch(
            session["clerk_session_id"]
        ):
            return None
        return session
    except (ValueError, TypeError, json.JSONDecodeError):
        return None


def issue_session(user_id: str, clerk_session_id: str) -> str:
    """Create the cookie value for a verified Clerk user and session."""
    if not isinstance(clerk_session_id, str) or not _SAFE_ID.fullmatch(clerk_session_id):
        raise ValueError("Valid Clerk session id required")
    return _encode(
        {
            "user_id": user_id,
            "clerk_session_id": clerk_session_id,
            "expires_at": int(time.time()) + SESSION_TTL_SECONDS,
        }
    )


# --- Who is signed in? -------------------------------------------------------

def current_user(request: Request) -> str | None:
    """
    Return the verified Clerk user id, or None.

    The answer is cached on request.state so several dependencies in one
    request cause only one call to Clerk.
    """
    if hasattr(request.state, "serenity_current_user"):
        return request.state.serenity_current_user
    cookie = request.cookies.get(AUTH_COOKIE)
    if not cookie:
        return None
    session = _decode(cookie)
    user_id = (
        session["user_id"]
        if session and _live_clerk_session(session["clerk_session_id"], session["user_id"])
        else None
    )
    request.state.serenity_current_user = user_id
    return user_id


def _workspace_for_request(request: Request, db: Session, clerk_user_id: str) -> str:
    """Map the verified Clerk user to their workspace id (cached per request)."""
    if hasattr(request.state, "serenity_workspace_id"):
        return request.state.serenity_workspace_id
    try:
        issuer = configured_clerk_issuer()
    except ValueError:
        # Without the issuer we cannot tell which Clerk instance vouched for
        # this user, so we refuse rather than guess.
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Sign-in is not configured",
        )
    try:
        workspace_id = identity_service.workspace_for_identity(
            db,
            provider=identity_service.CLERK_PROVIDER,
            issuer=issuer,
            subject=clerk_user_id,
        )
    except identity_service.InactiveUserError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This Serenity account has been deactivated",
        )
    except identity_service.IdentityError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Sign in required"
        )
    request.state.serenity_workspace_id = workspace_id
    return workspace_id


def require_session(request: Request, db: Session = Depends(get_db)) -> str:
    """API dependency: the caller's workspace id, or 401 when not signed in."""
    clerk_user_id = current_user(request)
    if clerk_user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Sign in required",
        )
    return _workspace_for_request(request, db, clerk_user_id)


def require_page_session(request: Request, db: Session = Depends(get_db)) -> str:
    """Page dependency: the caller's workspace id, or a redirect to sign-in."""
    clerk_user_id = current_user(request)
    if clerk_user_id is None:
        next_path = request.url.path
        if request.url.query:
            next_path += f"?{request.url.query}"
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            headers={"Location": f"/sign-in?next={quote(next_path, safe='/')}"},
            detail="Sign in required",
        )
    return _workspace_for_request(request, db, clerk_user_id)


# --- Talking to Clerk ---------------------------------------------------------

def _clerk_issuer() -> str:
    """
    Derive Clerk's issuer URL from our own publishable key.

    A publishable key is 'pk_test_' or 'pk_live_' + base64("<host>$").
    Trust comes from server configuration, never from claims in an incoming
    token, so a token signed by some other Clerk instance can't choose its
    own issuer.
    """
    key = os.getenv("CLERK_PUBLISHABLE_KEY", "")
    if not key.startswith(("pk_test_", "pk_live_")):
        raise ValueError("Missing Clerk configuration")
    encoded = key.split("_", 2)[2]
    host = base64.b64decode(encoded + "=" * (-len(encoded) % 4), validate=True).decode()
    if not host.endswith("$"):
        raise ValueError("Invalid Clerk configuration")
    host = host[:-1]
    if not re.fullmatch(r"[a-zA-Z0-9]+(?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?", host):
        raise ValueError("Invalid Clerk host")
    return f"https://{host}"


def configured_clerk_issuer() -> str:
    """Public name for the issuer: also the `issuer` stored on AuthIdentity rows."""
    return _clerk_issuer()


@lru_cache(maxsize=4)
def _jwks_client(issuer: str) -> jwt.PyJWKClient:
    """Clerk's public signing keys. PyJWT refetches on an unknown key id (rotation)."""
    return jwt.PyJWKClient(
        f"{issuer}/.well-known/jwks.json",
        lifespan=300,
        timeout=8,
        headers={"User-Agent": "Serenity/1.0", "Accept": "application/json"},
    )


def _authorized_parties() -> set[str]:
    """
    Origins allowed to have minted the token (Clerk's `azp` claim).

    Production origins are explicit (SERENITY_AUTHORIZED_PARTIES). Replit
    preview domains are added only in development (SERENITY_DEV=1).
    """
    parties = {
        origin.strip() for origin in
        os.getenv("SERENITY_AUTHORIZED_PARTIES", "").split(",") if origin.strip()
    }
    if os.getenv("SERENITY_DEV") == "1":
        parties.update(
            f"https://{host.strip()}" for host in
            os.getenv("REPLIT_DOMAINS", "").split(",") if host.strip()
        )
        domain = os.getenv("REPLIT_DEV_DOMAIN")
        if domain:
            parties.add(f"https://{domain}")
    return parties


def verify_clerk_token(token: str) -> tuple[str, str] | None:
    """
    Return (clerk_user_id, clerk_session_id) for a genuine, live Clerk token.

    Checks, in order: RS256 algorithm, signature against Clerk's published
    keys, issuer, required time claims, safe id formats, authorized party,
    and finally that Clerk still reports the session as active.
    """
    try:
        issuer = _clerk_issuer()
        header = jwt.get_unverified_header(token)
        if header.get("alg") != "RS256" or not isinstance(header.get("kid"), str):
            return None
        key = _jwks_client(issuer).get_signing_key_from_jwt(token)
        claims = jwt.decode(
            token, key.key, algorithms=["RS256"], issuer=issuer,
            options={"require": ["iss", "exp", "nbf", "iat", "sub", "sid"]},
        )
        for field in ("exp", "nbf", "iat"):
            if type(claims[field]) is not int:
                return None
        for field in ("sub", "sid"):
            if not isinstance(claims[field], str) or not _SAFE_ID.fullmatch(claims[field]):
                return None
        # This is a browser-only exchange: require azp, including when the
        # caller omits Origin. Never build the allowlist from request headers.
        if not isinstance(claims.get("azp"), str) or claims["azp"] not in _authorized_parties():
            return None
    except (jwt.PyJWTError, ValueError, TypeError, OSError):
        return None

    if not _live_clerk_session(claims["sid"], claims["sub"]):
        return None
    return claims["sub"], claims["sid"]


def _live_clerk_session(session_id: str, user_id: str) -> bool:
    """Ask Clerk's backend API. Fail closed on network errors, revocation or mismatch."""
    secret = os.getenv("CLERK_SECRET_KEY")
    if not secret:
        return False
    request = urllib.request.Request(
        f"https://api.clerk.com/v1/sessions/{session_id}",
        headers={
            "Authorization": f"Bearer {secret}",
            "User-Agent": "Serenity/1.0",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            session = json.loads(response.read())
    except urllib.error.HTTPError as error:
        # Log the status code only: never tokens, keys or user ids.
        logging.getLogger(__name__).warning(
            "Clerk session lookup failed with HTTP %s", error.code
        )
        return False
    except (urllib.error.URLError, TimeoutError, ValueError):
        logging.getLogger(__name__).warning("Clerk session lookup unavailable")
        return False

    return (isinstance(session, dict) and session.get("status") == "active"
            and session.get("user_id") == user_id)


def bearer_token(request: Request) -> str | None:
    """Read 'Authorization: Bearer <token>' from the request, if present."""
    authorization = request.headers.get("Authorization", "")
    scheme, _, token = authorization.partition(" ")
    return token if scheme.lower() == "bearer" and token else None
