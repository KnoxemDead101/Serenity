"""Add internal users, auth identities and workspaces; records belong to workspaces.

WHAT THIS MIGRATION DOES
------------------------
1. Creates three tables: users, workspaces, auth_identities
   (see models/identity.py for why each exists).
2. For every distinct `owner_id` already in the nine financial tables (these
   are Clerk user ids today), creates one SerenityUser + Workspace +
   AuthIdentity, then rewrites `owner_id` to the new workspace id.

Step 2 only matters for a database that already has rows (your development
database, test fixtures). Production was empty when this was written, and
production never runs Alembic anyway: Replit Publish copies the STRUCTURE,
i.e. the three new tables.

THE ISSUER
----------
An AuthIdentity is keyed on (provider, issuer, subject). The issuer is the
Clerk instance URL, derived from CLERK_PUBLISHABLE_KEY exactly as auth.py
does. Run this migration where that key is set (the Replit Shell has it)
so existing dev rows stay reachable after sign-in. Without the key, rows are
assigned issuer "unconfigured"; they are kept, but no sign-in will match
them until an administrator links the identity.

No foreign keys are added to the financial tables (see models/identity.py).
"""

import base64
import os
import re
import uuid
from datetime import datetime, timezone
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "0011_identity_and_workspaces"
down_revision: Union[str, None] = "0010_income_profiles"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

FINANCIAL_TABLES = (
    "accounts",
    "bills",
    "debts",
    "investments",
    "businesses",
    "dependents",
    "transactions",
    "transaction_corrections",
    "income_profiles",
)
UNCONFIGURED_ISSUER = "unconfigured"

# Lightweight table descriptions used only for the data step below.
# Migrations must not import app models: models change, migrations must not.
users_table = sa.table(
    "users",
    sa.column("id", sa.String),
    sa.column("active", sa.Boolean),
    sa.column("created_at", sa.DateTime(timezone=True)),
)
workspaces_table = sa.table(
    "workspaces",
    sa.column("id", sa.String),
    sa.column("owner_user_id", sa.String),
    sa.column("name", sa.String),
    sa.column("created_at", sa.DateTime(timezone=True)),
)
identities_table = sa.table(
    "auth_identities",
    sa.column("user_id", sa.String),
    sa.column("provider", sa.String),
    sa.column("issuer", sa.String),
    sa.column("subject", sa.String),
    sa.column("created_at", sa.DateTime(timezone=True)),
)


def _issuer_from_environment() -> str:
    """Same derivation as auth._clerk_issuer(), copied so migrations stay standalone."""
    key = os.getenv("CLERK_PUBLISHABLE_KEY", "")
    try:
        if not key.startswith(("pk_test_", "pk_live_")):
            raise ValueError
        encoded = key.split("_", 2)[2]
        host = base64.b64decode(encoded + "=" * (-len(encoded) % 4), validate=True).decode()
        if not host.endswith("$"):
            raise ValueError
        host = host[:-1]
        if not re.fullmatch(r"[a-zA-Z0-9]+(?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?", host):
            raise ValueError
        return f"https://{host}"
    except (ValueError, UnicodeDecodeError):
        return UNCONFIGURED_ISSUER


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("active", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "workspaces",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column(
            "owner_user_id", sa.String(length=36),
            sa.ForeignKey("users.id", name="fk_workspaces_owner_user_id"),
            nullable=False,
        ),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("owner_user_id", name="uq_workspaces_owner_user_id"),
    )
    op.create_table(
        "auth_identities",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "user_id", sa.String(length=36),
            sa.ForeignKey("users.id", name="fk_auth_identities_user_id"),
            nullable=False,
        ),
        sa.Column("provider", sa.String(length=50), nullable=False),
        sa.Column("issuer", sa.String(length=255), nullable=False),
        sa.Column("subject", sa.String(length=255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_sign_in_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint(
            "provider", "issuer", "subject",
            name="uq_auth_identities_provider_issuer_subject",
        ),
    )
    op.create_index("ix_auth_identities_user_id", "auth_identities", ["user_id"])

    # --- Data step: give every existing owner a user + workspace ---
    connection = op.get_bind()
    owners: set[str] = set()
    for table in FINANCIAL_TABLES:
        owners.update(
            row[0] for row in connection.execute(
                sa.text(f"SELECT DISTINCT owner_id FROM {table}")
            )
            if row[0]
        )
    if not owners:
        return

    issuer = _issuer_from_environment()
    if issuer == UNCONFIGURED_ISSUER:
        print(
            "WARNING: CLERK_PUBLISHABLE_KEY is not set; existing owners are "
            f"assigned issuer '{UNCONFIGURED_ISSUER}' and won't match a sign-in."
        )
    now = datetime.now(timezone.utc)
    for old_owner in sorted(owners):
        user_id = str(uuid.uuid4())
        workspace_id = str(uuid.uuid4())
        connection.execute(users_table.insert().values(
            id=user_id, active=True, created_at=now,
        ))
        connection.execute(workspaces_table.insert().values(
            id=workspace_id, owner_user_id=user_id, name="Primary", created_at=now,
        ))
        connection.execute(identities_table.insert().values(
            user_id=user_id, provider="clerk", issuer=issuer,
            subject=old_owner, created_at=now,
        ))
        for table in FINANCIAL_TABLES:
            connection.execute(
                sa.text(f"UPDATE {table} SET owner_id = :new WHERE owner_id = :old"),
                {"new": workspace_id, "old": old_owner},
            )


def downgrade() -> None:
    """Put the original external subject back into owner_id, then drop the tables."""
    connection = op.get_bind()
    mappings = connection.execute(sa.text(
        "SELECT workspaces.id, MIN(auth_identities.subject) "
        "FROM workspaces JOIN auth_identities "
        "ON auth_identities.user_id = workspaces.owner_user_id "
        "GROUP BY workspaces.id"
    )).fetchall()
    for workspace_id, subject in mappings:
        for table in FINANCIAL_TABLES:
            connection.execute(
                sa.text(f"UPDATE {table} SET owner_id = :subject WHERE owner_id = :ws"),
                {"subject": subject, "ws": workspace_id},
            )
    op.drop_index("ix_auth_identities_user_id", table_name="auth_identities")
    op.drop_table("auth_identities")
    op.drop_table("workspaces")
    op.drop_table("users")
