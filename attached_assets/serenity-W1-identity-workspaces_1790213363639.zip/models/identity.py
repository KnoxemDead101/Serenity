"""
Internal identity models: who a Serenity user is, independent of Clerk.

THE PROBLEM THESE SOLVE
-----------------------
Before migration 0011, every financial record stored the Clerk user id in
`owner_id`. That tied the user's money data to one authentication provider:
moving to a new Clerk instance (or away from Clerk) would produce a new
external id and orphan every record.

THE CHAIN
---------
    Clerk session (verified)
         |  provider + issuer + subject
         v
    AuthIdentity  ------->  SerenityUser  <-------  Workspace
    "this Clerk login        "this person,          "this person's financial
     belongs to..."           in Serenity's          data" (1 per user today)
                              own terms"
                                                          |
                                                          v
                                  accounts, transactions, bills, debts, ...
                                  (their `owner_id` column holds Workspace.id)

WHY `owner_id` WAS NOT RENAMED
------------------------------
Financial tables keep the column name `owner_id`; since 0011 its value is a
Workspace id, not a Clerk id. Renaming the column would touch ~30 files and,
once real data exists, Replit Publish's structure copy can treat a rename as
"drop column + add column", which loses data. Keeping the name is safe;
"owner" now simply means "the owning workspace".

WHY IDS ARE UUID STRINGS
------------------------
A UUID is random, so it never reveals how many users exist and it is safe to
create on any machine without asking the database for the next number. It is
stored as a 36-character string so SQLite and PostgreSQL behave identically.

There are deliberately no database foreign keys from financial tables to
`workspaces`: adding them would force SQLite to rebuild every table, and that
rebuild silently drops the expression indexes on businesses/dependents (see
migration 0008). Services and tests enforce the link instead.
"""

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean, DateTime, ForeignKey, Index, Integer, String, UniqueConstraint, true,
)
from sqlalchemy.orm import Mapped, mapped_column

from models.account import utc_now
from storage.database import Base

UUID_LENGTH = 36
PROVIDER_MAX_LENGTH = 50
EXTERNAL_ID_MAX_LENGTH = 255


def new_uuid() -> str:
    """A random UUID4 as text, e.g. '1b4e28ba-2fa1-11d2-883f-0016d3cca427'."""
    return str(uuid.uuid4())


class SerenityUser(Base):
    """A person who uses Serenity. Owns no credentials; Clerk does that."""

    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(UUID_LENGTH), primary_key=True, default=new_uuid)
    # False = the administrator has switched this user off. Every request is
    # refused with 403 even if their Clerk sign-in is still valid.
    active: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class Workspace(Base):
    """
    The container that owns a user's financial records.

    Today each user has exactly one (the UNIQUE constraint on owner_user_id
    enforces that). Keeping it separate from SerenityUser means a future
    backup/restore, or sharing, can move or grant a workspace without
    rewriting every financial row.
    """

    __tablename__ = "workspaces"
    __table_args__ = (
        UniqueConstraint("owner_user_id", name="uq_workspaces_owner_user_id"),
    )

    id: Mapped[str] = mapped_column(String(UUID_LENGTH), primary_key=True, default=new_uuid)
    owner_user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", name="fk_workspaces_owner_user_id"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(100), nullable=False, default="Primary")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class AuthIdentity(Base):
    """
    One external login that maps to a SerenityUser.

    The key is (provider, issuer, subject):
    - provider: which system signed the user in ("clerk").
    - issuer:   WHICH instance of that system, e.g. https://xyz.clerk.accounts.dev.
                Clerk user ids are only unique within one instance, so a new
                instance must never match an old identity by accident.
    - subject:  the provider's user id (Clerk's `sub` claim).

    Email is deliberately NOT stored or used. Emails change; matching on them
    could hand one person's finances to another.
    """

    __tablename__ = "auth_identities"
    __table_args__ = (
        UniqueConstraint(
            "provider", "issuer", "subject",
            name="uq_auth_identities_provider_issuer_subject",
        ),
        Index("ix_auth_identities_user_id", "user_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", name="fk_auth_identities_user_id"), nullable=False
    )
    provider: Mapped[str] = mapped_column(String(PROVIDER_MAX_LENGTH), nullable=False)
    issuer: Mapped[str] = mapped_column(String(EXTERNAL_ID_MAX_LENGTH), nullable=False)
    subject: Mapped[str] = mapped_column(String(EXTERNAL_ID_MAX_LENGTH), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    # Updated only when a new Serenity session is created (sign-in), never on
    # every request, so ordinary page loads don't write to the database.
    last_sign_in_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
