"""
Validation helpers for workspace-scoped financial records.

WHAT "OWNER" MEANS
------------------
Every financial table has an `owner_id` column. Since migration 0011 its
value is a WORKSPACE id (a UUID string from models/identity.py), not a Clerk
user id. auth.require_session() resolves the signed-in user to their
workspace, routes pass that id to services, and services filter every query
with `WHERE owner_id = <workspace id>`.

The column keeps the name `owner_id` on purpose; see models/identity.py.
"""

OWNER_ID_MAX_LENGTH = 255


class MissingOwnerError(ValueError):
    """A service was called without a usable owner (workspace) id."""


def require_owner_id(owner_id: str | None) -> str:
    """Return a valid owner id, refusing missing, blank, or oversized ids."""
    if not isinstance(owner_id, str) or not owner_id.strip():
        raise MissingOwnerError("An owner id is required for financial records.")
    if len(owner_id) > OWNER_ID_MAX_LENGTH:
        raise MissingOwnerError("Owner id is too long.")
    return owner_id
