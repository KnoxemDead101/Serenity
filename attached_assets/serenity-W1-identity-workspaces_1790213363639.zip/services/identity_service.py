"""
Identity service: turn a verified external login into a Serenity workspace id.

WHAT COMES IN
-------------
auth.py has ALREADY verified the Clerk session before calling anything here.
This module never checks passwords, tokens or cookies. It only answers:

    "Clerk instance X says this is user S. Which workspace is theirs?"

WHAT GOES OUT
-------------
A workspace id (UUID text). Routes pass it to every service as `owner_id`,
and every financial query filters on it.

PROVISIONING
------------
The first time a verified identity appears, this module creates, in ONE
database transaction:

    SerenityUser  +  Workspace ("Primary")  +  AuthIdentity

Who may reach this point is decided by Clerk: the Clerk dashboard must stay
in Restricted (invite-only) sign-up mode. That is Serenity's invite gate.

FAILING CLOSED
--------------
- A deactivated SerenityUser raises InactiveUserError (the route returns 403).
- Blank or oversized identity parts raise IdentityError, never a default.
- Two simultaneous first requests cannot create two workspaces: the UNIQUE
  constraint on (provider, issuer, subject) makes the second insert fail,
  and we then read the row the first request created.
"""

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from models.account import utc_now
from models.identity import (
    EXTERNAL_ID_MAX_LENGTH, PROVIDER_MAX_LENGTH, AuthIdentity, SerenityUser, Workspace,
)

CLERK_PROVIDER = "clerk"


class IdentityError(ValueError):
    """The identity parts were missing or malformed."""


class InactiveUserError(PermissionError):
    """The Serenity user exists but has been deactivated by the administrator."""


def _require_part(value: str | None, name: str, max_length: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise IdentityError(f"An identity {name} is required.")
    if len(value) > max_length:
        raise IdentityError(f"Identity {name} is too long.")
    return value


def _lookup(db: Session, provider: str, issuer: str, subject: str):
    """Return (workspace_id, user_active, identity) or None. Read-only."""
    row = db.execute(
        select(Workspace.id, SerenityUser.active, AuthIdentity)
        .join(SerenityUser, Workspace.owner_user_id == SerenityUser.id)
        .join(AuthIdentity, AuthIdentity.user_id == SerenityUser.id)
        .where(
            AuthIdentity.provider == provider,
            AuthIdentity.issuer == issuer,
            AuthIdentity.subject == subject,
        )
    ).first()
    return None if row is None else (row[0], row[1], row[2])


def _provision(db: Session, provider: str, issuer: str, subject: str) -> None:
    """Create user + workspace + identity together, or nothing at all."""
    user = SerenityUser()
    db.add(user)
    db.flush()  # assigns user.id so the rows below can point at it
    db.add(Workspace(owner_user_id=user.id, name="Primary"))
    db.add(AuthIdentity(
        user_id=user.id, provider=provider, issuer=issuer, subject=subject,
    ))
    db.commit()


def workspace_for_identity(
    db: Session, *, provider: str, issuer: str, subject: str,
    record_sign_in: bool = False,
) -> str:
    """
    Return the workspace id for a verified identity, provisioning it if new.

    record_sign_in=True also stamps AuthIdentity.last_sign_in_at. auth only
    asks for that when a new Serenity session is created, not on every request.
    """
    provider = _require_part(provider, "provider", PROVIDER_MAX_LENGTH)
    issuer = _require_part(issuer, "issuer", EXTERNAL_ID_MAX_LENGTH)
    subject = _require_part(subject, "subject", EXTERNAL_ID_MAX_LENGTH)

    found = _lookup(db, provider, issuer, subject)
    if found is None:
        try:
            _provision(db, provider, issuer, subject)
        except IntegrityError:
            # Another request provisioned the same identity a moment ago.
            db.rollback()
        found = _lookup(db, provider, issuer, subject)
        if found is None:  # should be impossible; never guess a workspace
            raise IdentityError("The identity could not be provisioned.")

    workspace_id, user_active, identity = found
    if not user_active:
        raise InactiveUserError("This Serenity user has been deactivated.")
    if record_sign_in:
        identity.last_sign_in_at = utc_now()
        db.commit()
    return workspace_id


def set_user_active(db: Session, user_id: str, active: bool) -> SerenityUser:
    """Administrator lever: switch a user off (or back on) without deleting data."""
    user = db.get(SerenityUser, user_id)
    if user is None:
        raise IdentityError("Unknown Serenity user.")
    user.active = active
    db.commit()
    return user
