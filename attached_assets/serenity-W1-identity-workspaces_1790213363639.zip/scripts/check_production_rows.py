"""
Read-only counts and ownership check for an explicitly selected database.

Run before every publish (see docs/security.md and docs/identity.md):

    SERENITY_CHECK_DATABASE_URL="<production url>" python scripts/check_production_rows.py

It prints COUNTS only, never names, amounts or ids, and exits non-zero when:
- any financial row has no owner_id, or
- (from migration 0011) any financial row's owner_id is not a workspace, or
- the production sign-in configuration check fails.
"""

import os
import sys

from sqlalchemy import create_engine, inspect, text
from check_production_auth import check_auth

TABLES = (
    "accounts", "transactions", "transaction_corrections", "businesses",
    "dependents", "bills", "debts", "investments", "income_profiles",
)
IDENTITY_TABLES = ("users", "workspaces", "auth_identities")


def main() -> int:
    auth_result = check_auth()
    url = os.getenv("SERENITY_CHECK_DATABASE_URL", "").strip()
    if not url:
        print("Set SERENITY_CHECK_DATABASE_URL to the database to inspect.", file=sys.stderr)
        return 2
    if url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://"):]
    if url.startswith("postgresql://"):
        url = "postgresql+psycopg://" + url[len("postgresql://"):]
    engine = create_engine(url)
    rows_total = 0
    unowned_total = 0
    orphaned_total = 0
    try:
        with engine.connect() as connection:
            if connection.dialect.name == "postgresql":
                connection.execute(text("SET TRANSACTION READ ONLY"))
            inspector = inspect(connection)
            present = set(inspector.get_table_names())
            has_workspaces = "workspaces" in present
            version = None
            if "alembic_version" in present:
                version = connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar()
            print(f"alembic_version: {version or '(none)'}")
            print(f"{'table':<28}{'rows':>8}  owner_id column  rows without owner"
                  + ("  rows not in a workspace" if has_workspaces else ""))
            for table in TABLES:
                if table not in present:
                    print(f"{table:<28}{'-':>8}  (table not present)")
                    continue
                count = connection.execute(text(f"SELECT COUNT(*) FROM {table}")).scalar()
                columns = {item["name"] for item in inspector.get_columns(table)}
                orphaned = 0
                if "owner_id" in columns:
                    unowned = connection.execute(text(
                        f"SELECT COUNT(*) FROM {table} "
                        "WHERE owner_id IS NULL OR trim(owner_id) = ''"
                    )).scalar()
                    owner_column = "yes"
                    if has_workspaces:
                        orphaned = connection.execute(text(
                            f"SELECT COUNT(*) FROM {table} "
                            "WHERE owner_id IS NOT NULL AND trim(owner_id) <> '' "
                            "AND owner_id NOT IN (SELECT id FROM workspaces)"
                        )).scalar()
                else:
                    unowned = count
                    owner_column = "NO"
                rows_total += count
                unowned_total += unowned
                orphaned_total += orphaned
                line = f"{table:<28}{count:>8}  {owner_column:<15}  {unowned}"
                if has_workspaces:
                    line += f"{'':<18}{orphaned}"
                print(line)
            for table in IDENTITY_TABLES:
                if table in present:
                    count = connection.execute(text(f"SELECT COUNT(*) FROM {table}")).scalar()
                    print(f"{table:<28}{count:>8}  (identity)")
            connection.rollback()
    finally:
        engine.dispose()
    if rows_total == 0:
        print("RESULT: no financial rows.")
    elif unowned_total:
        print(f"RESULT: {unowned_total} row(s) have no owner. Stop before publishing.")
    elif orphaned_total:
        print(f"RESULT: {orphaned_total} row(s) are not linked to a workspace. "
              "Stop before publishing.")
    else:
        print("RESULT: every row has an owner.")
    problems = unowned_total or orphaned_total
    return 0 if not problems and not auth_result else 1


if __name__ == "__main__":
    sys.exit(main())
