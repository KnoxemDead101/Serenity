"""
Export (backup) API routes.

    GET /serenity-api/export                    everything, as one JSON file
    GET /serenity-api/export/transactions.csv   transactions, as a spreadsheet

Both are sent as file DOWNLOADS (the Content-Disposition header tells the
browser to save the file instead of showing it).

SECURITY NOTE: these routes return ALL of your financial data. The
published app must be private (Replit "Invite only") before real data
goes in.
"""

import json
from datetime import date

from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy.orm import Session

from services import export_service
from storage.database import get_db

router = APIRouter(prefix="/serenity-api/export", tags=["Export"])


def _download(content: str, filename: str, media_type: str) -> Response:
    return Response(
        content=content,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("")
def export_everything(db: Session = Depends(get_db)):
    backup = export_service.build_export(db)
    return _download(
        json.dumps(backup, indent=2),
        f"serenity-backup-{date.today().isoformat()}.json",
        "application/json",
    )


@router.get("/transactions.csv")
def export_transactions_csv(db: Session = Depends(get_db)):
    return _download(
        export_service.build_transactions_csv(db),
        f"serenity-transactions-{date.today().isoformat()}.csv",
        "text/csv",
    )
