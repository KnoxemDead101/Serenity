#!/bin/bash
# ---------------------------------------------------------------------------
# Run this in the Replit Shell BEFORE every Publish:
#
#     bash scripts/prepublish_check.sh
#
# Why: Replit Publish copies the DEVELOPMENT database's structure to
# production. So the development database must already be at the latest
# Alembic migration, and the tests must pass, before you publish.
# (Production itself never runs Alembic; see docs/architecture.md.)
#
# In the Replit Shell, DATABASE_URL points at the development PostgreSQL
# database, so the commands below act on that database.
# ---------------------------------------------------------------------------
set -euo pipefail

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "DATABASE_URL is not set. Run this in the Replit Shell, where it points"
  echo "at the development PostgreSQL database."
  exit 1
fi

echo "1/3  Applying migrations to the development database..."
alembic upgrade head

echo "2/3  Checking the database is at the latest migration..."
current="$(alembic current 2>/dev/null | awk '{print $1}' | tail -n 1)"
head="$(alembic heads 2>/dev/null | awk '{print $1}' | tail -n 1)"
echo "     current: ${current}   head: ${head}"
if [[ "${current}" != "${head}" ]]; then
  echo "Development database is NOT at head. Do not publish."
  exit 1
fi

echo "3/3  Running the test suite..."
pytest -q

echo ""
echo "All checks passed. It is safe to Publish."
