"""Tests for services/dashboard_service.py: net worth in exact cents."""

from datetime import date
from decimal import Decimal

from schemas.account import AccountCreate
from schemas.finance import DebtCreate, InvestmentCreate
from schemas.transaction import TransactionCreate
from services import account_service, dashboard_service, finance_service, transaction_service


def test_net_worth_formula_in_cents():
    # $1,000.10 in accounts + $250.05 invested - $400.20 owed = $849.95
    assert dashboard_service.calculate_net_worth_cents(100_010, 25_005, 40_020) == 84_995
    # Owing more than you have gives a negative net worth.
    assert dashboard_service.calculate_net_worth_cents(0, 0, 150) == -150


def test_dashboard_net_worth_uses_every_source(db):
    account = account_service.create_account(db, AccountCreate(
        name="Checking", account_type="Checking", classification="Personal",
        opening_balance=Decimal("100.10"),
    ))
    transaction_service.create_transaction(db, account, TransactionCreate(
        date=date(2026, 9, 23), transaction_type="Expense",
        amount=Decimal("0.15"), description="Parking",
    ))
    finance_service.create_investment(db, InvestmentCreate(
        name="Index fund", quantity=Decimal("1"),
        cost_basis=Decimal("10.00"), current_value=Decimal("12.34"),
    ))
    finance_service.create_debt(db, DebtCreate(
        name="Card", debt_type="Credit Card", balance=Decimal("20.02"),
    ))

    summary = dashboard_service.get_dashboard_summary(db)

    # 100.10 - 0.15 + 12.34 - 20.02 = 92.27
    assert summary.total_balance == Decimal("99.95")
    assert summary.net_worth == Decimal("92.27")
