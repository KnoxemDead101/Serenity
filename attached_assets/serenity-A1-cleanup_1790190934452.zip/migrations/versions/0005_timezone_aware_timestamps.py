"""Make created_at / updated_at time-zone aware.

Revision ID: 0005_timezone_aware_timestamps
Revises: 0004_align_transactions_v02

WHY
---
Some timestamp columns stored a time zone (`deleted_at`, `changed_at`)
and some didn't (`created_at`, `updated_at`). Mixed rules cause subtle
bugs, like a time shown hours off. From now on EVERY timestamp is stored
as UTC with its time zone attached.

WHAT IT DOES
------------
PostgreSQL: changes each column from `timestamp` to `timestamptz`.
    `USING created_at AT TIME ZONE 'UTC'` tells Postgres "the old values
    were UTC", so no value changes; each simply gains its zone.

SQLite: nothing. SQLite has no separate time-zone-aware column type
    (dates are stored as text either way), so there is nothing to alter.
    Skipping it also avoids rebuilding tables for no benefit.

This changes structure only, no data values, so it is safe with
Replit Publish copying the development structure to production.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "0005_timezone_aware_timestamps"
down_revision: Union[str, None] = "0004_align_transactions_v02"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Every table whose created_at / updated_at were created without a zone.
TABLES = ["accounts", "bills", "debts", "investments", "transactions"]
COLUMNS = ["created_at", "updated_at"]


def _is_sqlite() -> bool:
    return op.get_bind().dialect.name == "sqlite"


def upgrade() -> None:
    if _is_sqlite():
        return
    for table in TABLES:
        for column in COLUMNS:
            op.alter_column(
                table,
                column,
                type_=sa.DateTime(timezone=True),
                existing_type=sa.DateTime(),
                existing_nullable=False,
                postgresql_using=f"{column} AT TIME ZONE 'UTC'",
            )


def downgrade() -> None:
    if _is_sqlite():
        return
    for table in TABLES:
        for column in COLUMNS:
            op.alter_column(
                table,
                column,
                type_=sa.DateTime(),
                existing_type=sa.DateTime(timezone=True),
                existing_nullable=False,
                # timestamptz AT TIME ZONE 'UTC' gives back the plain UTC time.
                postgresql_using=f"{column} AT TIME ZONE 'UTC'",
            )
