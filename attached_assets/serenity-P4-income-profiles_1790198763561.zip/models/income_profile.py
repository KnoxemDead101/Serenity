"""
Income Profile database model.

An Income Profile describes HOW you expect to be paid: "Warehouse job,
$22.50/hour, about 35 hours a week, paid every two weeks" or "Salary,
$78,000 a year, paid semimonthly".

It is a PLAN, not money that moved. When a paycheck actually lands, that
is an Income Transaction on an account. Serenity never creates
transactions from a profile automatically, so nothing is counted twice.

STORE FACTS, CALCULATE RESULTS
------------------------------
Only what you told us is stored here (rate, hours, salary, amount per
paycheck, frequency). Weekly/monthly/annual figures are calculated fresh
by services/income_profile_service.py every time they're shown, so they
can never drift out of date.

FIXED UNITS (never floats)
--------------------------
    money  -> integer cents          $22.50        -> 2250
    hours  -> integer hundredths     37.5 hours    -> 3750

Which columns are filled depends on income_type:

    Hourly     hourly_rate_cents, expected_hours_hundredths,
               (optional) standard_hours_hundredths, pay_frequency
    Salary     annual_salary_cents, pay_frequency
    Recurring  amount_per_period_cents, pay_frequency
    Other      amount_per_period_cents, pay_frequency
    Variable   (optional) amount_per_period_cents as a "typical" amount,
               (optional) pay_frequency. NEVER projected as guaranteed.

Columns that don't apply to the type are always NULL (the schema clears
them), so an old salary figure can't linger on an hourly profile.
"""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Index, Integer, String, Text, true
from sqlalchemy.orm import Mapped, mapped_column

from models.account import utc_now
from services.ownership import OWNER_ID_MAX_LENGTH
from storage.database import Base


class IncomeProfile(Base):
    __tablename__ = "income_profiles"
    __table_args__ = (Index("ix_income_profiles_owner_id", "owner_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    # Clerk user id of the owner. Required; never defaulted (services/ownership.py).
    owner_id: Mapped[str] = mapped_column(String(OWNER_ID_MAX_LENGTH), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    # Hourly, Salary, Recurring, Variable or Other (utils/choices.py).
    income_type: Mapped[str] = mapped_column(String(20), nullable=False)
    # Personal / Business / Investment / Trading, same list as accounts.
    classification: Mapped[str] = mapped_column(String(20), nullable=False, default="Personal")
    # Weekly, Biweekly, Semimonthly, Monthly or Annual. NULL only for Variable.
    pay_frequency: Mapped[str | None] = mapped_column(String(20))

    hourly_rate_cents: Mapped[int | None] = mapped_column(Integer)
    # "Standard" = contracted/full-time hours; "expected" = what you really
    # expect to work. Projections use EXPECTED hours.
    standard_hours_hundredths: Mapped[int | None] = mapped_column(Integer)
    expected_hours_hundredths: Mapped[int | None] = mapped_column(Integer)
    annual_salary_cents: Mapped[int | None] = mapped_column(Integer)
    amount_per_period_cents: Mapped[int | None] = mapped_column(Integer)
    # What you actually expect to receive per paycheck after taxes and
    # deductions, if you know it. Serenity does NOT calculate taxes.
    expected_net_per_period_cents: Mapped[int | None] = mapped_column(Integer)

    notes: Mapped[str | None] = mapped_column(Text)
    # False = deactivated. Kept for history, excluded from totals, never deleted.
    active: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, onupdate=utc_now
    )
