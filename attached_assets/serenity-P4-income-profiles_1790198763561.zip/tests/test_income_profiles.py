"""
Income Profiles: validation, calculations, lifecycle, ownership, export.

Calculations are checked against numbers worked out by hand, including
the classic mistake Serenity must NOT make (monthly = weekly x 4).
"""

from decimal import Decimal

import pytest

from conftest import TEST_OWNER_ID, sign_in_as
from models.income_profile import IncomeProfile
from schemas.income_profile import IncomeProfileCreate
from services import income_profile_service as service
from services.ownership import MissingOwnerError

URL = "/serenity-api/income-profiles"

HOURLY = {
    "name": "Warehouse", "income_type": "Hourly", "pay_frequency": "Biweekly",
    "hourly_rate": "20.00", "expected_hours_per_week": "40",
    "standard_hours_per_week": "40",
}
SALARY = {
    "name": "Office", "income_type": "Salary", "pay_frequency": "Semimonthly",
    "annual_salary": "78000.00", "expected_net_per_period": "2400.00",
}
RECURRING = {
    "name": "Stipend", "income_type": "Recurring", "pay_frequency": "Weekly",
    "amount_per_period": "100.00",
}
VARIABLE = {"name": "Tips", "income_type": "Variable", "amount_per_period": "60.00"}


def build(**fields) -> IncomeProfile:
    """A transient (unsaved) profile built through the real schema."""
    profile = IncomeProfile(owner_id=TEST_OWNER_ID, active=True)
    service._apply(profile, IncomeProfileCreate(**fields))
    return profile


# --- Calculations -------------------------------------------------------

def test_hourly_uses_the_yearly_total_not_weekly_times_four():
    calc = service.calculate(build(**HOURLY))
    assert calc.gross_weekly == Decimal("800.00")      # 20 x 40
    assert calc.gross_annual == Decimal("41600.00")    # 800 x 52
    assert calc.gross_monthly == Decimal("3466.67")    # 41600 / 12, NOT 3200
    assert calc.gross_per_period == Decimal("1600.00")  # 41600 / 26
    assert calc.standard_weekly_gross == Decimal("800.00")
    assert calc.net_monthly is None                   # no take-home given


def test_hourly_fractional_rate_and_hours_round_once():
    calc = service.calculate(build(
        name="Part time", income_type="Hourly", pay_frequency="Weekly",
        hourly_rate="22.37", expected_hours_per_week="37.5",
    ))
    assert calc.gross_weekly == Decimal("838.88")      # 838.875 -> 838.88
    assert calc.gross_annual == Decimal("43621.50")    # exact
    assert calc.gross_monthly == Decimal("3635.13")    # 3635.125 -> 3635.13


def test_projections_use_expected_hours_not_standard():
    calc = service.calculate(build(**{**HOURLY, "expected_hours_per_week": "30"}))
    assert calc.gross_weekly == Decimal("600.00")
    assert calc.standard_weekly_gross == Decimal("800.00")


@pytest.mark.parametrize("frequency,per_period", [
    ("Weekly", "1500.00"), ("Biweekly", "3000.00"), ("Semimonthly", "3250.00"),
    ("Monthly", "6500.00"), ("Annual", "78000.00"),
])
def test_salary_per_paycheck_for_every_frequency(frequency, per_period):
    calc = service.calculate(build(**{**SALARY, "pay_frequency": frequency,
                                     "expected_net_per_period": None}))
    assert calc.gross_per_period == Decimal(per_period)
    assert calc.gross_monthly == Decimal("6500.00")
    assert calc.gross_weekly == Decimal("1500.00")


def test_salary_that_does_not_divide_evenly():
    calc = service.calculate(build(
        name="S", income_type="Salary", pay_frequency="Biweekly", annual_salary="50000",
    ))
    assert calc.gross_per_period == Decimal("1923.08")
    assert calc.gross_weekly == Decimal("961.54")
    assert calc.gross_monthly == Decimal("4166.67")


def test_net_is_scaled_from_the_users_own_take_home_figure():
    calc = service.calculate(build(**SALARY))
    assert calc.net_per_period == Decimal("2400.00")
    assert calc.net_annual == Decimal("57600.00")     # 2400 x 24
    assert calc.net_monthly == Decimal("4800.00")


def test_recurring_weekly_amount_monthly_is_not_times_four():
    calc = service.calculate(build(**RECURRING))
    assert calc.gross_annual == Decimal("5200.00")
    assert calc.gross_monthly == Decimal("433.33")     # not 400.00


def test_variable_income_is_never_projected():
    calc = service.calculate(build(**VARIABLE))
    assert calc.projected is False
    assert calc.gross_monthly is None and calc.gross_annual is None
    assert calc.net_monthly is None


def test_summary_adds_exact_values_and_rounds_once():
    profiles = [build(**{**RECURRING, "name": f"R{i}"}) for i in range(3)]
    # 3 x 433.333... = 1300.00 exactly (rounding each first would give 1299.99)
    summary = service.summarize(profiles)
    assert summary.gross_monthly == Decimal("1300.00")
    assert summary.net_monthly is None and summary.net_is_partial is False


def test_summary_excludes_inactive_and_variable_and_flags_partial_net():
    inactive = build(**SALARY)
    inactive.active = False
    summary = service.summarize([
        build(**HOURLY), build(**SALARY), build(**VARIABLE), inactive,
    ])
    assert summary.active_count == 3
    assert summary.projected_count == 2
    assert summary.variable_count == 1
    assert summary.gross_annual == Decimal("119600.00")   # 41600 + 78000
    assert summary.net_profile_count == 1
    assert summary.net_monthly == Decimal("4800.00")
    assert summary.net_is_partial is True


# --- Validation ---------------------------------------------------------

@pytest.mark.parametrize("body,message", [
    ({**HOURLY, "hourly_rate": None}, "Hourly rate"),
    ({**HOURLY, "expected_hours_per_week": None}, "Expected hours"),
    ({**HOURLY, "expected_hours_per_week": "168.01"}, "at most 168"),
    ({**HOURLY, "expected_hours_per_week": "0"}, "more than 0"),
    ({**HOURLY, "expected_hours_per_week": "10.125"}, "2 decimal places"),
    ({**HOURLY, "hourly_rate": "10.005"}, "2 decimal places"),
    ({**HOURLY, "pay_frequency": None}, "pay frequency"),
    ({**SALARY, "annual_salary": "-1"}, "more than 0"),
    ({**SALARY, "pay_frequency": "Fortnightly"}, "Pay frequency must be one of"),
    ({**RECURRING, "amount_per_period": None}, "Amount per paycheck"),
    ({**VARIABLE, "expected_net_per_period": "10.00"}, "needs a pay frequency"),
    ({**VARIABLE, "income_type": "Bonus"}, "Income type must be one of"),
    ({**VARIABLE, "name": "   "}, "Name is required"),
    ({**VARIABLE, "classification": "Savings"}, "Classification must be one of"),
])
def test_invalid_profiles_are_rejected(client, body, message):
    response = client.post(URL, json=body)
    assert response.status_code == 422
    assert message in response.text
    assert client.get(URL).json() == []


def test_fields_that_dont_belong_to_the_type_are_cleared(client):
    body = {**HOURLY, "annual_salary": "90000.00", "amount_per_period": "5.00"}
    created = client.post(URL, json=body).json()
    assert created["annual_salary"] is None
    assert created["amount_per_period"] is None
    assert created["hourly_rate"] == "20.00"


def test_blank_form_fields_mean_not_provided(client):
    created = client.post(URL, json={**VARIABLE, "pay_frequency": "",
                                     "amount_per_period": ""})
    assert created.status_code == 201
    assert created.json()["pay_frequency"] is None


# --- API: create, list, edit, lifecycle ----------------------------------

def test_create_returns_facts_and_calculations_as_strings(client):
    response = client.post(URL, json=HOURLY)
    assert response.status_code == 201
    body = response.json()
    assert body["hourly_rate"] == "20.00"
    assert body["expected_hours_per_week"] == "40.00"
    assert body["calculated"]["gross_monthly"] == "3466.67"
    assert body["calculated"]["projected"] is True
    assert body["active"] is True


def test_edit_is_a_full_replacement_and_changes_type_cleanly(client):
    created = client.post(URL, json=HOURLY).json()
    response = client.put(f"{URL}/{created['id']}", json=SALARY)
    assert response.status_code == 200
    body = response.json()
    assert body["income_type"] == "Salary"
    assert body["hourly_rate"] is None and body["expected_hours_per_week"] is None
    assert body["calculated"]["gross_monthly"] == "6500.00"


def test_deactivate_and_reactivate_never_delete(client):
    created = client.post(URL, json=SALARY).json()
    assert client.get(f"{URL}/summary").json()["gross_monthly"] == "6500.00"

    off = client.post(f"{URL}/{created['id']}/deactivate")
    assert off.status_code == 200 and off.json()["active"] is False
    assert client.get(f"{URL}/summary").json()["gross_monthly"] == "0.00"
    assert [p["id"] for p in client.get(URL).json()] == [created["id"]]  # still listed

    on = client.post(f"{URL}/{created['id']}/reactivate")
    assert on.json()["active"] is True
    assert client.delete(f"{URL}/{created['id']}").status_code == 405  # no hard delete


def test_summary_endpoint_totals(client):
    client.post(URL, json=HOURLY)
    client.post(URL, json=SALARY)
    client.post(URL, json=VARIABLE)
    summary = client.get(f"{URL}/summary").json()
    assert summary["gross_monthly"] == "9966.67"   # (41600 + 78000) / 12
    assert summary["gross_annual"] == "119600.00"
    assert summary["variable_count"] == 1
    assert summary["net_is_partial"] is True


def test_options_and_unknown_ids(client):
    options = client.get(f"{URL}/options").json()
    assert options["income_types"] == ["Hourly", "Salary", "Recurring", "Variable", "Other"]
    assert options["pay_frequencies"] == ["Weekly", "Biweekly", "Semimonthly", "Monthly", "Annual"]
    assert client.get(f"{URL}/999").status_code == 404
    assert client.post(f"{URL}/999/deactivate").status_code == 404


def test_income_profiles_do_not_create_transactions_or_change_net_worth(client):
    client.post(URL, json=SALARY)
    summary = client.get("/serenity-api/dashboard/summary").json()
    assert summary["net_worth"] == "0.00"
    backup = client.get("/serenity-api/export").json()
    assert backup["transactions"] == []
    assert backup["income_profiles"][0]["annual_salary_cents"] == 7_800_000


# --- Ownership --------------------------------------------------------------

def test_service_requires_an_owner(db):
    data = IncomeProfileCreate(**SALARY)
    for bad in (None, "", "   "):
        with pytest.raises(MissingOwnerError):
            service.create_income_profile(db, data, bad)
        with pytest.raises(MissingOwnerError):
            service.list_income_profiles(db, bad)


def test_another_user_cannot_see_or_change_income_profiles(real_auth_client):
    client = real_auth_client
    sign_in_as(client, "owner-a")
    profile = client.post(URL, json=SALARY).json()

    sign_in_as(client, "owner-b")
    assert client.get(URL).json() == []
    assert client.get(f"{URL}/summary").json()["gross_monthly"] == "0.00"
    assert client.get(f"{URL}/{profile['id']}").status_code == 404
    assert client.put(f"{URL}/{profile['id']}", json=HOURLY).status_code == 404
    assert client.post(f"{URL}/{profile['id']}/deactivate").status_code == 404
    assert client.get("/serenity-api/export").json()["income_profiles"] == []

    sign_in_as(client, "owner-a")
    mine = client.get(f"{URL}/{profile['id']}").json()
    assert mine["income_type"] == "Salary" and mine["active"] is True


def test_income_page_and_api_require_sign_in(real_auth_client):
    page = real_auth_client.get("/income", follow_redirects=False)
    assert page.status_code == 307
    assert page.headers["location"] == "/sign-in?next=/income"
    assert real_auth_client.get(URL).status_code == 401
    assert real_auth_client.get(f"{URL}/summary").status_code == 401


def test_leftover_invalid_fields_from_another_type_are_ignored(client):
    response = client.post(URL, json={**HOURLY, "annual_salary": "-5", "amount_per_period": "abc"})
    assert response.status_code == 201
    assert response.json()["annual_salary"] is None


@pytest.mark.parametrize("body", [
    {**SALARY, "annual_salary": "20000000.01"},
    {**VARIABLE, "name": "x" * 101},
])
def test_amount_and_name_limits(client, body):
    assert client.post(URL, json=body).status_code == 422
