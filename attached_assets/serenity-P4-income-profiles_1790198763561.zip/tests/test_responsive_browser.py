"""Responsive layout and theme checks in real Chromium.

Phone:   390 x 844 (a typical modern phone)
Desktop: 1280 x 800

These check LAYOUT only (menu, overflow, tap sizes, theme tokens). The
numbers on screen always come from the API; nothing is calculated here.
"""

import pytest

expect = pytest.importorskip("playwright.sync_api").expect

PHONE = {"width": 390, "height": 844}
DESKTOP = {"width": 1280, "height": 800}
PAGES = ["/", "/accounts", "/finances", "/income", "/setup"]


def horizontal_overflow(page):
    return page.evaluate(
        "() => document.documentElement.scrollWidth - document.documentElement.clientWidth"
    )


@pytest.mark.parametrize("path", PAGES)
def test_pages_fit_a_phone_without_sideways_scrolling(page, path):
    page.set_viewport_size(PHONE)
    page.goto(f"http://serenity.test{path}")
    expect(page.locator("h1")).to_be_visible()
    assert horizontal_overflow(page) <= 1


@pytest.mark.parametrize("path", PAGES)
def test_phone_menu_opens_and_closes(page, path):
    page.set_viewport_size(PHONE)
    page.goto(f"http://serenity.test{path}")
    toggle = page.get_by_role("button", name="Menu")
    nav = page.locator("#site-nav")

    expect(toggle).to_be_visible()
    expect(toggle).to_have_attribute("aria-expanded", "false")
    expect(nav).to_be_hidden()

    toggle.click()
    expect(toggle).to_have_attribute("aria-expanded", "true")
    expect(nav.get_by_role("link", name="Accounts")).to_be_visible()
    expect(nav.get_by_role("link", name="Sign out")).to_be_visible()

    page.keyboard.press("Escape")
    expect(toggle).to_have_attribute("aria-expanded", "false")
    expect(nav).to_be_hidden()


def test_phone_menu_links_are_finger_sized(page):
    page.set_viewport_size(PHONE)
    page.goto("http://serenity.test/")
    page.get_by_role("button", name="Menu").click()
    for link in page.locator("#site-nav a").all():
        assert link.bounding_box()["height"] >= 44


def test_desktop_shows_links_and_hides_menu_button(page):
    page.set_viewport_size(DESKTOP)
    page.goto("http://serenity.test/accounts")
    expect(page.get_by_role("button", name="Menu")).to_be_hidden()
    expect(page.locator("#site-nav").get_by_role("link", name="Dashboard")).to_be_visible()
    active = page.locator("#site-nav a.active")
    expect(active).to_have_text("Accounts")
    expect(active).to_have_attribute("aria-current", "page")


def test_add_transaction_form_is_usable_on_a_phone(page, client):
    client.post("/serenity-api/accounts", json={
        "name": "Checking", "account_type": "Checking", "classification": "Personal",
    })
    page.set_viewport_size(PHONE)
    page.goto("http://serenity.test/accounts")
    form = page.locator("#transaction-form")
    submit = form.get_by_role("button", name="Record transaction")
    expect(submit).to_be_visible()
    assert submit.bounding_box()["height"] >= 44
    amount = form.locator("[name=amount]")
    assert amount.bounding_box()["height"] >= 44
    # Fields stack into one column: every field is (almost) the form's width.
    form_width = form.bounding_box()["width"]
    assert amount.bounding_box()["width"] >= form_width * 0.9


def test_phone_transaction_history_hides_secondary_columns_only(page, client):
    account = client.post("/serenity-api/accounts", json={
        "name": "Checking", "account_type": "Checking", "classification": "Personal",
    }).json()
    client.post(f"/serenity-api/accounts/{account['id']}/transactions", json={
        "date": "2026-09-21", "transaction_type": "Expense", "amount": "5.00",
        "description": "Coffee", "merchant": "Corner Store",
    })
    page.set_viewport_size(PHONE)
    page.goto("http://serenity.test/accounts")
    row = page.locator("#transactions-body tr").filter(has_text="Coffee")
    expect(row).to_be_visible()
    cells = row.locator("td")
    expect(cells).to_have_count(9)              # data is all still there
    expect(cells.nth(3)).to_be_hidden()          # Merchant hidden on phone
    expect(cells.nth(7)).to_be_visible()         # Amount always visible
    expect(row.get_by_role("button", name="Edit")).to_be_visible()


def test_dark_theme_tokens_and_system_font(page):
    page.goto("http://serenity.test/")
    styles = page.evaluate("""() => {
      const root = getComputedStyle(document.documentElement);
      const body = getComputedStyle(document.body);
      return {
        background: root.getPropertyValue("--color-background").trim(),
        primary: root.getPropertyValue("--color-primary").trim(),
        bodyBackground: body.backgroundColor,
        font: body.fontFamily,
      };
    }""")
    assert styles["background"] == "#0a0a0a"
    assert styles["primary"] == "#c9a44c"
    assert styles["bodyBackground"] == "rgb(10, 10, 10)"
    assert "system-ui" in styles["font"]
