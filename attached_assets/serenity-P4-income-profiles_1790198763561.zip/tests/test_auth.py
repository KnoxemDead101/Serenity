"""
Tests that financial pages, APIs and downloads require a Serenity session,
and that there is no hidden test-user shortcut in production code.
"""

import inspect

import auth
from auth import AUTH_COOKIE, issue_session
from conftest import sign_in_as

FINANCIAL_PAGES = ("/", "/accounts", "/finances", "/setup", "/income")
FINANCIAL_APIS = (
    "/serenity-api/accounts",
    "/serenity-api/transactions/options",
    "/serenity-api/bills",
    "/serenity-api/debts",
    "/serenity-api/investments",
    "/serenity-api/businesses",
    "/serenity-api/dependents",
    "/serenity-api/dashboard/summary",
    "/serenity-api/income-profiles",
    "/serenity-api/income-profiles/summary",
    "/serenity-api/finance/summary",
    "/serenity-api/export",
    "/serenity-api/export/transactions.csv",
)


def test_signed_out_visitors_are_redirected_from_pages(real_auth_client):
    for path in FINANCIAL_PAGES:
        response = real_auth_client.get(path, follow_redirects=False)
        assert response.status_code == 307, path
        assert response.headers["location"] == f"/sign-in?next={path}"


def test_signed_out_visitors_get_401_from_apis_and_downloads(real_auth_client):
    for path in FINANCIAL_APIS:
        assert real_auth_client.get(path).status_code == 401, path


def test_signed_out_visitors_cannot_write(real_auth_client):
    response = real_auth_client.post("/serenity-api/accounts", json={
        "name": "Nope", "account_type": "Checking", "classification": "Personal",
    })
    assert response.status_code == 401


def test_signed_session_can_reach_financial_data(real_auth_client):
    sign_in_as(real_auth_client, "invited-user")
    assert real_auth_client.get("/").status_code == 200
    assert real_auth_client.get("/serenity-api/accounts").status_code == 200
    assert real_auth_client.get("/serenity-api/export").status_code == 200


def test_tampered_cookie_is_rejected(real_auth_client):
    good = issue_session("invited-user")
    payload, signature = good.split(".", 1)
    tampered = payload[:-2] + ("AA" if payload[-2:] != "AA" else "BB") + "." + signature
    real_auth_client.cookies.set(AUTH_COOKIE, tampered)
    assert real_auth_client.get("/serenity-api/accounts").status_code == 401


def test_expired_session_is_rejected(real_auth_client, monkeypatch):
    sign_in_as(real_auth_client, "invited-user")
    # Pretend 13 hours have passed (sessions last 12).
    future = auth.time.time() + 13 * 60 * 60
    monkeypatch.setattr(auth.time, "time", lambda: future)
    assert real_auth_client.get("/serenity-api/accounts").status_code == 401
    response = real_auth_client.get("/accounts", follow_redirects=False)
    assert response.status_code == 307


def test_sign_out_clears_the_cookie(real_auth_client):
    sign_in_as(real_auth_client, "invited-user")
    response = real_auth_client.delete("/serenity-api/auth/session")
    assert response.status_code == 200
    real_auth_client.cookies.clear()
    assert real_auth_client.get("/serenity-api/accounts").status_code == 401


def test_production_auth_has_no_test_user_bypass():
    """Guard against a 'pretend to be a test user' switch creeping back in."""
    source = inspect.getsource(auth)
    assert "auth_bypass" not in source
    assert "test-user" not in source


def test_redirect_keeps_the_page_query_inside_next(real_auth_client):
    response = real_auth_client.get("/accounts?view=all&page=2", follow_redirects=False)
    assert response.status_code == 307
    assert response.headers["location"] == "/sign-in?next=/accounts%3Fview%3Dall%26page%3D2"
