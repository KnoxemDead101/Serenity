"""The Income page in real Chromium: type-specific fields, add, edit, deactivate.

The `page` fixture lives in conftest.py (skips if Chromium is missing).
Figures on screen come from the API; the page only displays them.
"""

import pytest

expect = pytest.importorskip("playwright.sync_api").expect

URL = "/serenity-api/income-profiles"


def test_fields_follow_the_income_type(page):
    page.goto("http://serenity.test/income")
    form = page.locator("#income-form")
    expect(form.locator("[name=hourly_rate]")).to_be_visible()
    expect(form.locator("[name=annual_salary]")).to_be_hidden()

    form.locator("[name=income_type]").select_option("Salary")
    expect(form.locator("[name=annual_salary]")).to_be_visible()
    expect(form.locator("[name=hourly_rate]")).to_be_hidden()

    form.locator("[name=income_type]").select_option("Variable")
    expect(form.locator("#amount-label")).to_contain_text("never projected")


def test_add_hourly_profile_shows_server_calculated_figures(page, client):
    page.goto("http://serenity.test/income")
    form = page.locator("#income-form")
    form.locator("[name=name]").fill("Warehouse")
    form.locator("[name=hourly_rate]").fill("20.00")
    form.locator("[name=expected_hours_per_week]").fill("40")
    form.get_by_role("button", name="Add income profile").click()

    expect(page.locator("#income-message")).to_have_text('Added "Warehouse".')
    row = page.locator("#incomes-body tr").filter(has_text="Warehouse")
    expect(row).to_contain_text("$3,466.67")          # 41,600 / 12, not 800 x 4
    expect(page.locator("#gross-monthly")).to_have_text("$3,466.67")
    saved = client.get(URL).json()[0]
    assert saved["income_type"] == "Hourly" and saved["pay_frequency"] == "Biweekly"


def test_validation_error_keeps_the_form_filled(page):
    page.goto("http://serenity.test/income")
    form = page.locator("#income-form")
    form.locator("[name=name]").fill("Too many hours")
    form.locator("[name=hourly_rate]").fill("20.00")
    # Bypass the browser's own max=168 check to prove the SERVER rejects it.
    form.locator("[name=expected_hours_per_week]").evaluate("el => el.removeAttribute('max')")
    form.locator("[name=expected_hours_per_week]").fill("200")
    form.get_by_role("button", name="Add income profile").click()
    expect(page.locator("#income-message")).to_contain_text("at most 168")
    expect(form.locator("[name=name]")).to_have_value("Too many hours")


def test_edit_and_deactivate_profile(page, client):
    created = client.post(URL, json={
        "name": "Office", "income_type": "Salary", "pay_frequency": "Monthly",
        "annual_salary": "60000.00",
    }).json()
    page.goto("http://serenity.test/income")
    row = page.locator("#incomes-body tr").filter(has_text="Office")
    expect(row).to_contain_text("$5,000.00")
    row.get_by_role("button", name="Edit").click()
    form = page.locator("#income-form")
    expect(form.locator("[name=annual_salary]")).to_have_value("60000.00")
    form.locator("[name=annual_salary]").fill("72000.00")
    form.get_by_role("button", name="Save income profile").click()
    expect(page.locator("#income-message")).to_have_text('Saved "Office".')
    expect(row).to_contain_text("$6,000.00")

    page.once("dialog", lambda dialog: dialog.accept())
    row.get_by_role("button", name="Deactivate").click()
    expect(row).to_contain_text("Inactive")
    expect(page.locator("#gross-monthly")).to_have_text("$0.00")
    assert client.get(f"{URL}/{created['id']}").json()["active"] is False


def test_variable_profile_is_marked_not_projected(page, client):
    client.post(URL, json={"name": "Tips", "income_type": "Variable"})
    page.goto("http://serenity.test/income")
    row = page.locator("#incomes-body tr").filter(has_text="Tips")
    expect(row).to_contain_text("Not projected")
    expect(page.locator("#summary-note")).to_contain_text("not included in the totals")
