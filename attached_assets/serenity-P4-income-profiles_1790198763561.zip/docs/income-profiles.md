# Income Profiles

An Income Profile describes how you EXPECT to be paid. It is a plan, not
money received. Actual paychecks are Income Transactions on an account.
Serenity never creates transactions from a profile, so nothing is counted
twice, and profiles never change balances or net worth.

## Data flow

```
frontend/incomes.html + static/js/incomes.js     form, table, show/hide fields
        │  JSON (money and hours as text, e.g. "22.50", "37.5")
        ▼
api/income_profiles.py                          thin routes; user id from require_session
        ▼
schemas/income_profile.py (Pydantic)             validates, requires the type's fields,
        │                                        clears the fields that don't apply
        ▼
services/income_profile_service.py               converts to fixed units, stores facts,
        │                                        CALCULATES weekly/monthly/yearly figures
        ▼
models/income_profile.py -> income_profiles      migration 0010_income_profiles
```

`owner_id` enters at `require_session` (the signed-in Clerk user), is passed
by every route, and is enforced by the service (`require_owner_id` plus a
`WHERE owner_id = ...` on every read). Another user's profile id returns 404.

## What is stored (facts)

| Field | Unit | Used by |
| --- | --- | --- |
| `hourly_rate_cents` | cents | Hourly |
| `expected_hours_hundredths` | hundredths of an hour (37.5 h → 3750) | Hourly (projections) |
| `standard_hours_hundredths` | hundredths of an hour | Hourly (reference only) |
| `annual_salary_cents` | cents | Salary |
| `amount_per_period_cents` | cents | Recurring, Other; Variable "typical" (never projected) |
| `pay_frequency` | Weekly / Biweekly / Semimonthly / Monthly / Annual | all except Variable (optional there) |
| `expected_net_per_period_cents` | cents | optional take-home from your pay stub |

Nothing calculated is stored.

## Formulas (calculated on every read)

Paychecks per year: Weekly 52, Biweekly 26, Semimonthly 24, Monthly 12, Annual 1.

First the exact yearly gross (kept as an exact fraction of cents):

- Hourly: `hourly rate × expected hours per week × 52`
- Salary: `annual salary`
- Recurring / Other: `amount per paycheck × paychecks per year`
- Variable: **not projected** (every figure is empty)

Then each shown figure divides that yearly total and rounds half-up **once**:

- per paycheck = yearly ÷ paychecks per year
- weekly = yearly ÷ 52
- monthly = yearly ÷ 12 — never "weekly × 4" (that would be a 48-week year)

Worked example: $20/h × 40 h = $800/week → $41,600/year → **$3,466.67/month**
(weekly × 4 would wrongly give $3,200).

Take-home: Serenity has no tax engine. If you enter the take-home per
paycheck, net yearly = take-home × paychecks per year and net monthly =
that ÷ 12. Without it, net figures stay empty.

Summary (`/serenity-api/income-profiles/summary`): adds the exact yearly
figures of ACTIVE, non-Variable profiles, then rounds once. Net totals
include only profiles that have a take-home amount; `net_is_partial` says
when some don't.

## Lifecycle

Create, list, edit (full replacement), deactivate, reactivate. No delete.
Deactivated profiles stay listed and leave the totals.

## Manual test

1. Income → add Hourly, $20.00, 40 h/week, Biweekly. Row shows $1,600.00 per
   paycheck, $3,466.67 / month, $41,600.00 / year.
2. Edit it to Salary $78,000 Semimonthly with take-home $2,400. Hourly fields
   disappear; row shows $3,250.00, $6,500.00, take-home $4,800.00 / month.
3. Add Variable "Tips". It shows "Not projected" and the note under the cards.
4. Deactivate the salary profile. Totals drop to $0.00; the row stays, marked
   Inactive. Reactivate restores it.
5. Download the JSON backup: `income_profiles` lists the stored facts.
6. Sign in as a different invited user: the Income page is empty.

## Deferred (not built)

Goals, budgets, scenarios, projection timelines, paycheck ↔ transaction
matching, automatic income transactions, tax estimates.
