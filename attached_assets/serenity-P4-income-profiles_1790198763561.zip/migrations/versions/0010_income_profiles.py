"""Add Income Profiles (how you expect to be paid).

Revision ID: 0010_income_profiles
Revises: 0009_owner_id_indexes

WHAT IT DOES
------------
Creates one new table, `income_profiles`, plus its owner_id lookup index.
Nothing existing is changed and no rows are written, so this is
structure-only and safe for Replit Publish to copy to production.

Money is integer cents; hours are integer hundredths (37.5 h -> 3750).
Which columns are filled depends on income_type; see
models/income_profile.py.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "0010_income_profiles"
down_revision: Union[str, None] = "0009_owner_id_indexes"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "income_profiles",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("owner_id", sa.String(length=255), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("income_type", sa.String(length=20), nullable=False),
        sa.Column("classification", sa.String(length=20), nullable=False),
        sa.Column("pay_frequency", sa.String(length=20), nullable=True),
        sa.Column("hourly_rate_cents", sa.Integer(), nullable=True),
        sa.Column("standard_hours_hundredths", sa.Integer(), nullable=True),
        sa.Column("expected_hours_hundredths", sa.Integer(), nullable=True),
        sa.Column("annual_salary_cents", sa.Integer(), nullable=True),
        sa.Column("amount_per_period_cents", sa.Integer(), nullable=True),
        sa.Column("expected_net_per_period_cents", sa.Integer(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_income_profiles_owner_id", "income_profiles", ["owner_id"])


def downgrade() -> None:
    op.drop_index("ix_income_profiles_owner_id", table_name="income_profiles")
    op.drop_table("income_profiles")
