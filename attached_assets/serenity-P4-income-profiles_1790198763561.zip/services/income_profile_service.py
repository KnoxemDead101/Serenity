"""
Income Profile service: store income facts, calculate expected pay.

    api/income_profiles.py -> services/income_profile_service.py -> database

THE FORMULAS (all in integer cents, rounded ONCE per shown figure)
-----------------------------------------------------------------
Everything goes through the exact YEARLY total first, kept as a Fraction
(an exact ratio of two integers, so nothing is lost before rounding):

    Hourly     annual = hourly rate x expected hours per week x 52
    Salary     annual = annual salary
    Recurring  annual = amount per paycheck x paychecks per year
    Other      annual = amount per paycheck x paychecks per year
    Variable   NOT projected (all figures None)

Paychecks per year: Weekly 52, Biweekly 26, Semimonthly 24, Monthly 12,
Annual 1 (utils/choices.py).

Then each figure is the yearly total divided, and rounded half-up once:

    per paycheck = annual / paychecks per year
    weekly       = annual / 52
    monthly      = annual / 12      <- never "weekly x 4"
    annual       = annual

Example: $20/h x 40 h = $800/week -> annual $41,600 -> monthly $3,466.67.
("weekly x 4" would wrongly say $3,200.)

Net (take-home) is never calculated from gross; Serenity has no tax
engine. If you enter an expected take-home per paycheck, it is scaled the
same way: net annual = take-home x paychecks per year, net monthly =
that / 12.

OWNERSHIP
---------
create/list/get/summary take a REQUIRED owner_id (services/ownership.py).
"""

from decimal import Decimal
from fractions import Fraction
from typing import Iterable

from sqlalchemy import select
from sqlalchemy.orm import Session

from models.income_profile import IncomeProfile
from schemas.income_profile import (
    IncomeCalculation,
    IncomeProfileCreate,
    IncomeProfileRead,
    IncomeProfileUpdate,
    IncomeSummary,
)
from services.ownership import require_owner_id
from utils.choices import (
    ACCOUNT_CLASSIFICATIONS,
    INCOME_TYPES,
    PAY_FREQUENCIES,
    PAY_PERIODS_PER_YEAR,
)
from utils.money import cents_to_dollars, dollars_to_cents, round_half_up_division

WEEKS_PER_YEAR = 52
MONTHS_PER_YEAR = 12
HUNDREDTHS_PER_HOUR = 100


# --- Fixed-unit conversions for hours ---------------------------------

def hours_to_hundredths(hours: Decimal) -> int:
    """37.5 hours -> 3750. Validation already limited it to 2 decimals."""
    units = hours * HUNDREDTHS_PER_HOUR
    if units != units.to_integral_value():
        raise ValueError(f"{hours} has more than 2 decimal places")
    return int(units)


def hundredths_to_hours(units: int) -> Decimal:
    """3750 -> Decimal("37.50")."""
    return (Decimal(units) / HUNDREDTHS_PER_HOUR).quantize(Decimal("0.01"))


def _cents_or_none(value: Decimal | None) -> int | None:
    return dollars_to_cents(value) if value is not None else None


def _dollars_or_none(cents: int | None) -> Decimal | None:
    return cents_to_dollars(cents) if cents is not None else None


def _round(exact: Fraction) -> int:
    """Round an exact Fraction of cents to whole cents, half-up, ONCE."""
    return round_half_up_division(exact.numerator, exact.denominator)


# --- Calculations ------------------------------------------------------

def is_projected(profile: IncomeProfile) -> bool:
    """Variable income is never projected as guaranteed pay."""
    return profile.income_type != "Variable"


def periods_per_year(profile: IncomeProfile) -> int | None:
    if profile.pay_frequency is None:
        return None
    return PAY_PERIODS_PER_YEAR[profile.pay_frequency]


def exact_annual_gross_cents(profile: IncomeProfile) -> Fraction | None:
    """The exact yearly gross in cents, or None if it isn't projected."""
    if not is_projected(profile):
        return None
    if profile.income_type == "Hourly":
        # rate (cents/hour) x hours/week (in hundredths, so / 100) x 52 weeks
        return (
            Fraction(profile.hourly_rate_cents)
            * Fraction(profile.expected_hours_hundredths, HUNDREDTHS_PER_HOUR)
            * WEEKS_PER_YEAR
        )
    if profile.income_type == "Salary":
        return Fraction(profile.annual_salary_cents)
    # Recurring and Other: a fixed amount every pay period.
    return Fraction(profile.amount_per_period_cents) * periods_per_year(profile)


def exact_annual_net_cents(profile: IncomeProfile) -> Fraction | None:
    """Yearly take-home from the user's own per-paycheck figure, if given."""
    if not is_projected(profile) or profile.expected_net_per_period_cents is None:
        return None
    return Fraction(profile.expected_net_per_period_cents) * periods_per_year(profile)


def _basis(profile: IncomeProfile) -> str:
    """A short plain-English description of how the figures were made."""
    if profile.income_type == "Hourly":
        return "hourly rate x expected hours per week x 52 weeks"
    if profile.income_type == "Salary":
        return "annual salary divided into pay periods"
    if profile.income_type == "Variable":
        return "variable income is not projected"
    return f"amount per paycheck x {periods_per_year(profile)} paychecks a year"


def calculate(profile: IncomeProfile) -> IncomeCalculation:
    """All displayed figures for one profile, each rounded once."""
    annual = exact_annual_gross_cents(profile)
    if annual is None:
        return IncomeCalculation(
            projected=False, basis=_basis(profile),
            gross_per_period=None, gross_weekly=None, gross_monthly=None,
            gross_annual=None, standard_weekly_gross=None,
            net_per_period=None, net_monthly=None, net_annual=None,
        )

    periods = periods_per_year(profile)
    standard_weekly = None
    if profile.income_type == "Hourly" and profile.standard_hours_hundredths is not None:
        standard_weekly = _round(
            Fraction(profile.hourly_rate_cents)
            * Fraction(profile.standard_hours_hundredths, HUNDREDTHS_PER_HOUR)
        )

    net_annual = exact_annual_net_cents(profile)
    return IncomeCalculation(
        projected=True,
        basis=_basis(profile),
        gross_per_period=cents_to_dollars(_round(annual / periods)),
        gross_weekly=cents_to_dollars(_round(annual / WEEKS_PER_YEAR)),
        gross_monthly=cents_to_dollars(_round(annual / MONTHS_PER_YEAR)),
        gross_annual=cents_to_dollars(_round(annual)),
        standard_weekly_gross=_dollars_or_none(standard_weekly),
        net_per_period=_dollars_or_none(profile.expected_net_per_period_cents),
        net_monthly=(
            cents_to_dollars(_round(net_annual / MONTHS_PER_YEAR))
            if net_annual is not None else None
        ),
        net_annual=cents_to_dollars(_round(net_annual)) if net_annual is not None else None,
    )


def summarize(profiles: Iterable[IncomeProfile]) -> IncomeSummary:
    """
    Totals across ACTIVE profiles. Exact yearly figures are added first and
    rounded once at the end, so rounding errors can't pile up.
    """
    active = [p for p in profiles if p.active is not False]
    projected = [p for p in active if is_projected(p)]
    with_net = [p for p in projected if p.expected_net_per_period_cents is not None]

    gross_annual = sum((exact_annual_gross_cents(p) for p in projected), Fraction(0))
    net_annual = sum((exact_annual_net_cents(p) for p in with_net), Fraction(0))
    has_net = bool(with_net)
    return IncomeSummary(
        active_count=len(active),
        projected_count=len(projected),
        variable_count=len(active) - len(projected),
        gross_monthly=cents_to_dollars(_round(gross_annual / MONTHS_PER_YEAR)),
        gross_annual=cents_to_dollars(_round(gross_annual)),
        net_profile_count=len(with_net),
        net_monthly=cents_to_dollars(_round(net_annual / MONTHS_PER_YEAR)) if has_net else None,
        net_annual=cents_to_dollars(_round(net_annual)) if has_net else None,
        net_is_partial=has_net and len(with_net) < len(projected),
    )


# --- Create / read / update ------------------------------------------------

def _apply(profile: IncomeProfile, data: IncomeProfileCreate) -> None:
    """Copy validated input onto the model, converting to fixed units."""
    profile.name = data.name
    profile.income_type = data.income_type
    profile.classification = data.classification
    profile.pay_frequency = data.pay_frequency
    profile.hourly_rate_cents = _cents_or_none(data.hourly_rate)
    profile.standard_hours_hundredths = (
        hours_to_hundredths(data.standard_hours_per_week)
        if data.standard_hours_per_week is not None else None
    )
    profile.expected_hours_hundredths = (
        hours_to_hundredths(data.expected_hours_per_week)
        if data.expected_hours_per_week is not None else None
    )
    profile.annual_salary_cents = _cents_or_none(data.annual_salary)
    profile.amount_per_period_cents = _cents_or_none(data.amount_per_period)
    profile.expected_net_per_period_cents = _cents_or_none(data.expected_net_per_period)
    profile.notes = data.notes


def create_income_profile(db: Session, data: IncomeProfileCreate, owner_id: str) -> IncomeProfile:
    profile = IncomeProfile(owner_id=require_owner_id(owner_id), active=True)
    _apply(profile, data)
    db.add(profile)
    db.commit()
    db.refresh(profile)
    return profile


def list_income_profiles(db: Session, owner_id: str) -> list[IncomeProfile]:
    """Active profiles first, then by name."""
    return list(db.scalars(
        select(IncomeProfile)
        .where(IncomeProfile.owner_id == require_owner_id(owner_id))
        .order_by(IncomeProfile.active.desc(), IncomeProfile.name, IncomeProfile.id)
    ))


def get_income_profile(db: Session, profile_id: int, owner_id: str) -> IncomeProfile | None:
    """None when it doesn't exist OR belongs to someone else (API: 404)."""
    return db.scalars(select(IncomeProfile).where(
        IncomeProfile.id == profile_id,
        IncomeProfile.owner_id == require_owner_id(owner_id),
    )).first()


def update_income_profile(
    db: Session, profile: IncomeProfile, data: IncomeProfileUpdate
) -> IncomeProfile:
    _apply(profile, data)
    db.commit()
    db.refresh(profile)
    return profile


def set_income_profile_active(db: Session, profile: IncomeProfile, active: bool) -> IncomeProfile:
    """Deactivate/reactivate. Profiles are never hard-deleted."""
    profile.active = active
    db.commit()
    db.refresh(profile)
    return profile


def get_income_summary(db: Session, owner_id: str) -> IncomeSummary:
    return summarize(list_income_profiles(db, owner_id))


def get_income_options() -> dict[str, list[str]]:
    return {
        "income_types": INCOME_TYPES,
        "pay_frequencies": PAY_FREQUENCIES,
        "classifications": ACCOUNT_CLASSIFICATIONS,
    }


def to_income_profile_read(profile: IncomeProfile) -> IncomeProfileRead:
    """Stored facts (converted back to dollars/hours) + calculated figures."""
    return IncomeProfileRead(
        id=profile.id,
        name=profile.name,
        income_type=profile.income_type,
        classification=profile.classification,
        pay_frequency=profile.pay_frequency,
        hourly_rate=_dollars_or_none(profile.hourly_rate_cents),
        standard_hours_per_week=(
            hundredths_to_hours(profile.standard_hours_hundredths)
            if profile.standard_hours_hundredths is not None else None
        ),
        expected_hours_per_week=(
            hundredths_to_hours(profile.expected_hours_hundredths)
            if profile.expected_hours_hundredths is not None else None
        ),
        annual_salary=_dollars_or_none(profile.annual_salary_cents),
        amount_per_period=_dollars_or_none(profile.amount_per_period_cents),
        expected_net_per_period=_dollars_or_none(profile.expected_net_per_period_cents),
        notes=profile.notes,
        active=profile.active,
        calculated=calculate(profile),
        created_at=profile.created_at,
        updated_at=profile.updated_at,
    )
