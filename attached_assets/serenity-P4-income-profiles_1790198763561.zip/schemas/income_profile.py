"""
Income Profile request/response shapes and validation.

    frontend form -> JSON -> IncomeProfileCreate (this file) -> service

WHAT THE VALIDATION GUARANTEES
------------------------------
The fields you must fill depend on the income type:

    Hourly     hourly_rate, expected_hours_per_week, pay_frequency
               (standard_hours_per_week optional)
    Salary     annual_salary, pay_frequency
    Recurring  amount_per_period, pay_frequency
    Other      amount_per_period, pay_frequency
    Variable   nothing extra; amount_per_period ("typical") and
               pay_frequency are optional and are never projected

Fields that DON'T belong to the chosen type are cleared to None, so a
leftover salary can't hide inside an hourly profile.

Money: at most 2 decimal places, never negative, never a float.
Hours: more than 0, at most 168 a week, at most 2 decimal places.
"""

from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, field_validator, model_validator

from schemas.timestamps import TimestampReadModel
from utils.choices import ACCOUNT_CLASSIFICATIONS, INCOME_TYPES, PAY_FREQUENCIES
from utils.validators import optional_text, require_choice, require_text, validate_money

HOURS_PER_WEEK_MAX = Decimal("168")  # 24 x 7
# Money columns are 32-bit integers of cents (max about $21.4 million), so
# income amounts are capped well inside that limit.
INCOME_MONEY_MAX = Decimal("20000000")

# Which optional fields each type is allowed to keep.
TYPE_FIELDS = {
    "Hourly": {"hourly_rate", "standard_hours_per_week", "expected_hours_per_week"},
    "Salary": {"annual_salary"},
    "Recurring": {"amount_per_period"},
    "Other": {"amount_per_period"},
    "Variable": {"amount_per_period"},
}
# ...and which of those are required.
TYPE_REQUIRED = {
    "Hourly": {"hourly_rate": "Hourly rate", "expected_hours_per_week": "Expected hours per week"},
    "Salary": {"annual_salary": "Annual salary"},
    "Recurring": {"amount_per_period": "Amount per paycheck"},
    "Other": {"amount_per_period": "Amount per paycheck"},
    "Variable": {},
}
TYPE_SPECIFIC = {
    "hourly_rate", "standard_hours_per_week", "expected_hours_per_week",
    "annual_salary", "amount_per_period",
}


def validate_positive_money(value: Decimal | None, field_name: str) -> Decimal | None:
    if value is None:
        return None
    value = validate_money(value, field_name)
    if value <= 0:
        raise ValueError(f"{field_name} must be more than 0")
    if value > INCOME_MONEY_MAX:
        raise ValueError(f"{field_name} must be at most 20,000,000")
    return value


def validate_hours(value: Decimal | None, field_name: str) -> Decimal | None:
    if value is None:
        return None
    if not value.is_finite() or value <= 0 or value > HOURS_PER_WEEK_MAX:
        raise ValueError(f"{field_name} must be more than 0 and at most 168")
    if value.quantize(Decimal("0.01")) != value:
        raise ValueError(f"{field_name} can have at most 2 decimal places")
    return value


class IncomeProfileCreate(BaseModel):
    name: str
    income_type: str
    classification: str = "Personal"
    pay_frequency: str | None = None
    hourly_rate: Decimal | None = None
    standard_hours_per_week: Decimal | None = None
    expected_hours_per_week: Decimal | None = None
    annual_salary: Decimal | None = None
    amount_per_period: Decimal | None = None
    expected_net_per_period: Decimal | None = None
    notes: str | None = None

    @field_validator("name")
    @classmethod
    def check_name(cls, value: str) -> str:
        return require_text(value, "Name", max_length=100)

    @field_validator("income_type")
    @classmethod
    def check_type(cls, value: str) -> str:
        return require_choice(value, INCOME_TYPES, "Income type")

    @field_validator("classification")
    @classmethod
    def check_classification(cls, value: str) -> str:
        return require_choice(value, ACCOUNT_CLASSIFICATIONS, "Classification")

    @field_validator("pay_frequency", mode="before")
    @classmethod
    def check_frequency(cls, value):
        if value is None or (isinstance(value, str) and not value.strip()):
            return None  # a blank dropdown means "not set"
        return require_choice(value, PAY_FREQUENCIES, "Pay frequency")

    # Blank form fields arrive as "" - treat them as "not provided".
    @field_validator(
        "hourly_rate", "standard_hours_per_week", "expected_hours_per_week",
        "annual_salary", "amount_per_period", "expected_net_per_period",
        mode="before",
    )
    @classmethod
    def blank_is_none(cls, value):
        if isinstance(value, str) and not value.strip():
            return None
        return value

    @field_validator("hourly_rate")
    @classmethod
    def check_rate(cls, value):
        return validate_positive_money(value, "Hourly rate")

    @field_validator("annual_salary")
    @classmethod
    def check_salary(cls, value):
        return validate_positive_money(value, "Annual salary")

    @field_validator("amount_per_period")
    @classmethod
    def check_amount(cls, value):
        return validate_positive_money(value, "Amount per paycheck")

    @field_validator("expected_net_per_period")
    @classmethod
    def check_net(cls, value):
        return validate_positive_money(value, "Expected take-home per paycheck")

    @field_validator("standard_hours_per_week")
    @classmethod
    def check_standard_hours(cls, value):
        return validate_hours(value, "Standard hours per week")

    @field_validator("expected_hours_per_week")
    @classmethod
    def check_expected_hours(cls, value):
        return validate_hours(value, "Expected hours per week")

    @field_validator("notes")
    @classmethod
    def check_notes(cls, value: str | None) -> str | None:
        return optional_text(value, 1000)

    @model_validator(mode="before")
    @classmethod
    def clear_fields_for_other_types(cls, data):
        """
        Throw away fields that don't belong to the chosen type BEFORE they
        are validated, so a leftover value can't cause an error or be saved.
        """
        if isinstance(data, dict) and data.get("income_type") in TYPE_FIELDS:
            data = dict(data)
            for field in TYPE_SPECIFIC - TYPE_FIELDS[data["income_type"]]:
                data[field] = None
        return data

    @model_validator(mode="after")
    def check_fields_for_type(self):
        """Require the fields the chosen type needs."""
        kind = self.income_type
        missing = [label for field, label in TYPE_REQUIRED[kind].items()
                   if getattr(self, field) is None]
        if missing:
            raise ValueError(f"{kind} income needs: {', '.join(missing)}")
        if kind != "Variable" and self.pay_frequency is None:
            raise ValueError(f"{kind} income needs a pay frequency")
        if self.expected_net_per_period is not None and self.pay_frequency is None:
            raise ValueError("Expected take-home per paycheck needs a pay frequency")
        return self


class IncomeProfileUpdate(IncomeProfileCreate):
    """Edits are full replacements, like the other Serenity records."""


class IncomeCalculation(BaseModel):
    """
    Figures CALCULATED by the service from the stored facts.

    projected = False for Variable income: every projection is None,
    because variable pay must never be treated as guaranteed.
    Net figures are None unless you supplied an expected take-home amount.
    """

    projected: bool
    basis: str
    gross_per_period: Decimal | None
    gross_weekly: Decimal | None
    gross_monthly: Decimal | None
    gross_annual: Decimal | None
    standard_weekly_gross: Decimal | None
    net_per_period: Decimal | None
    net_monthly: Decimal | None
    net_annual: Decimal | None


class IncomeProfileRead(TimestampReadModel):
    id: int
    name: str
    income_type: str
    classification: str
    pay_frequency: str | None
    hourly_rate: Decimal | None
    standard_hours_per_week: Decimal | None
    expected_hours_per_week: Decimal | None
    annual_salary: Decimal | None
    amount_per_period: Decimal | None
    expected_net_per_period: Decimal | None
    notes: str | None
    active: bool
    calculated: IncomeCalculation
    created_at: datetime
    updated_at: datetime


class IncomeSummary(BaseModel):
    """Totals across ACTIVE, projected (non-Variable) profiles."""

    active_count: int
    projected_count: int
    variable_count: int
    gross_monthly: Decimal
    gross_annual: Decimal
    # Net totals only include profiles where you entered take-home pay.
    net_profile_count: int
    net_monthly: Decimal | None
    net_annual: Decimal | None
    # True when some projected profiles have no take-home amount, so the
    # net total covers only part of your income.
    net_is_partial: bool
