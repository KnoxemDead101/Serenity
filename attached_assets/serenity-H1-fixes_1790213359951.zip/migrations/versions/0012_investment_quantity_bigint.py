"""Widen investments.quantity_units to a 64-bit integer.

At 1e-8 units per share, a 32-bit PostgreSQL INTEGER overflows above about
21.47 shares. BIGINT removes that limit. See models/investment.py.

SQLite stores every INTEGER as up to 64 bits already, so on SQLite this
migration does nothing (and avoids a batch table rebuild).

Production: Replit Publish sees the development column is BIGINT and applies
the same type change to production. Widening a column never loses data.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "0012_investment_quantity_bigint"
down_revision: Union[str, None] = "0011_identity_and_workspaces"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    if op.get_bind().dialect.name == "sqlite":
        return
    op.alter_column(
        "investments", "quantity_units",
        existing_type=sa.Integer(), type_=sa.BigInteger(),
    )


def downgrade() -> None:
    # Narrowing fails if any stored quantity no longer fits in 32 bits,
    # which is the correct outcome: never truncate someone's holdings.
    if op.get_bind().dialect.name == "sqlite":
        return
    op.alter_column(
        "investments", "quantity_units",
        existing_type=sa.BigInteger(), type_=sa.Integer(),
    )
