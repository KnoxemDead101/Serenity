"""Add the owner_id lookup indexes the models declare.

WHY THIS EXISTS
---------------
Migration 0008 added an `owner_id` column to every financial table, but it
did not create the plain lookup indexes that the models declare, e.g.

    models/account.py:  Index("ix_accounts_owner_id", "owner_id")

Every list/read in Serenity now filters by owner_id
("WHERE owner_id = :signed_in_user"), so without these indexes the
database would scan the whole table on each request. It also means the
database built by Alembic and the one the models describe disagreed,
which is exactly the kind of drift that confuses Replit's
development -> production schema publish.

SAFE TO RE-RUN
--------------
`if_not_exists=True` means: if an index with this name is already there
(for example, Replit Publish or a test database created it), skip it
instead of failing. This changes structure only; no rows are touched.

businesses and dependents don't need one here: their
(owner_id, name) unique constraints from 0008 already begin with
owner_id, so the database can use them for owner lookups.
"""

from typing import Sequence, Union

from alembic import op

revision: str = "0009_owner_id_indexes"
down_revision: Union[str, None] = "0008_record_ownership"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# (index name, table) — names match the models' __table_args__ exactly.
OWNER_INDEXES = (
    ("ix_accounts_owner_id", "accounts"),
    ("ix_bills_owner_id", "bills"),
    ("ix_debts_owner_id", "debts"),
    ("ix_investments_owner_id", "investments"),
    ("ix_transactions_owner_id", "transactions"),
    ("ix_transaction_corrections_owner_id", "transaction_corrections"),
)


def upgrade() -> None:
    for index_name, table in OWNER_INDEXES:
        op.create_index(index_name, table, ["owner_id"], if_not_exists=True)


def downgrade() -> None:
    for index_name, table in reversed(OWNER_INDEXES):
        op.drop_index(index_name, table_name=table, if_exists=True)
