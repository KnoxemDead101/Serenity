"""
Every signed-in user sees and changes ONLY their own financial records.

Two real users ("owner-a" and "owner-b") sign in with genuine signed
cookies. Owner A creates one of everything; then owner B tries to read,
change, deactivate, link to and export it. Every attempt must fail as if
the record didn't exist (404 / 422 "doesn't exist"), and A's data must
come through unchanged.
"""

import pytest

from conftest import sign_in_as

ACCOUNT = {"name": "A Checking", "account_type": "Checking",
           "classification": "Personal", "opening_balance": "100.00"}
TRANSACTION = {"date": "2026-09-23", "transaction_type": "Expense",
               "amount": "10.00", "description": "Owner A purchase"}


@pytest.fixture
def owner_a_records(real_auth_client):
    """Owner A signs in and creates one of every record type."""
    client = real_auth_client
    sign_in_as(client, "owner-a")
    account = client.post("/serenity-api/accounts", json=ACCOUNT).json()
    transaction = client.post(
        f"/serenity-api/accounts/{account['id']}/transactions", json=TRANSACTION
    ).json()
    records = {
        "account": account,
        "transaction": transaction,
        "business": client.post("/serenity-api/businesses", json={"name": "A Business"}).json(),
        "dependent": client.post(
            "/serenity-api/dependents", json={"display_name": "A Dependent"}
        ).json(),
        "bill": client.post("/serenity-api/bills", json={
            "name": "A Bill", "amount": "25.00", "due_date": "2026-10-01",
        }).json(),
        "debt": client.post("/serenity-api/debts", json={
            "name": "A Debt", "debt_type": "Credit Card", "balance": "50.00",
        }).json(),
        "investment": client.post("/serenity-api/investments", json={
            "name": "A Investment", "cost_basis": "40.00", "current_value": "45.00",
        }).json(),
    }
    sign_in_as(client, "owner-b")
    return client, records


def test_lists_and_options_are_empty_for_another_user(owner_a_records):
    client, _ = owner_a_records
    for path in ("accounts", "bills", "debts", "investments", "businesses", "dependents"):
        assert client.get(f"/serenity-api/{path}").json() == [], path
    options = client.get("/serenity-api/transactions/options").json()
    assert options["businesses"] == [] and options["dependents"] == []


def test_direct_reads_are_404(owner_a_records):
    client, r = owner_a_records
    a = r["account"]["id"]
    assert client.get(f"/serenity-api/accounts/{a}").status_code == 404
    assert client.get(f"/serenity-api/accounts/{a}/transactions").status_code == 404
    assert client.get(f"/serenity-api/accounts/{a}/transaction-corrections").status_code == 404
    for kind in ("bill", "debt", "investment"):
        assert client.get(f"/serenity-api/{kind}s/{r[kind]['id']}").status_code == 404, kind


def test_edits_are_404_and_change_nothing(owner_a_records):
    client, r = owner_a_records
    a = r["account"]["id"]
    assert client.put(f"/serenity-api/accounts/{a}",
                      json={**ACCOUNT, "name": "Hijacked"}).status_code == 404
    t = r["transaction"]["id"]
    assert client.put(f"/serenity-api/accounts/{a}/transactions/{t}",
                      json={**TRANSACTION, "amount": "1.00"}).status_code == 404
    assert client.delete(f"/serenity-api/accounts/{a}/transactions/{t}").status_code == 404
    assert client.put(f"/serenity-api/bills/{r['bill']['id']}", json={
        "name": "Hijacked", "amount": "1.00", "due_date": "2026-10-01"}).status_code == 404
    assert client.put(f"/serenity-api/debts/{r['debt']['id']}", json={
        "name": "Hijacked", "balance": "1.00"}).status_code == 404
    assert client.put(f"/serenity-api/investments/{r['investment']['id']}", json={
        "name": "Hijacked", "cost_basis": "1.00", "current_value": "1.00"}).status_code == 404
    assert client.put(f"/serenity-api/businesses/{r['business']['id']}",
                      json={"name": "Hijacked"}).status_code == 404
    assert client.put(f"/serenity-api/dependents/{r['dependent']['id']}",
                      json={"display_name": "Hijacked"}).status_code == 404

    # Owner A's data is untouched.
    sign_in_as(client, "owner-a")
    assert client.get(f"/serenity-api/accounts/{a}").json()["name"] == "A Checking"
    assert client.get(f"/serenity-api/accounts/{a}").json()["current_balance"] == "90.00"
    assert client.get(f"/serenity-api/bills/{r['bill']['id']}").json()["name"] == "A Bill"
    assert [b["name"] for b in client.get("/serenity-api/businesses").json()] == ["A Business"]


@pytest.mark.parametrize("kind", ["accounts", "bills", "debts", "investments",
                                  "businesses", "dependents"])
@pytest.mark.parametrize("action", ["deactivate", "reactivate"])
def test_lifecycle_actions_are_404(owner_a_records, kind, action):
    client, r = owner_a_records
    record_id = r[kind[:-1] if kind != "businesses" else "business"]["id"]
    assert client.post(f"/serenity-api/{kind}/{record_id}/{action}").status_code == 404
    sign_in_as(client, "owner-a")
    listed = {item["id"]: item for item in client.get(f"/serenity-api/{kind}").json()}
    assert listed[record_id]["active"] is True


def test_cannot_link_another_users_business_or_dependent(owner_a_records):
    """Cross-record ownership: B guesses A's business/dependent ids."""
    client, r = owner_a_records
    b_account = client.post("/serenity-api/accounts", json={**ACCOUNT, "name": "B Checking"}).json()
    url = f"/serenity-api/accounts/{b_account['id']}/transactions"

    with_business = client.post(url, json={**TRANSACTION, "business_id": r["business"]["id"]})
    assert with_business.status_code == 422
    assert "doesn't exist" in with_business.json()["detail"]
    with_dependent = client.post(url, json={**TRANSACTION, "dependent_id": r["dependent"]["id"]})
    assert with_dependent.status_code == 422

    # Same check on UPDATE of B's own transaction.
    own = client.post(url, json=TRANSACTION).json()
    update = client.put(f"{url}/{own['id']}",
                        json={**TRANSACTION, "business_id": r["business"]["id"]})
    assert update.status_code == 422
    assert client.get(url).json()[0]["business_id"] is None


def test_cannot_record_on_another_users_account(owner_a_records):
    client, r = owner_a_records
    url = f"/serenity-api/accounts/{r['account']['id']}/transactions"
    assert client.post(url, json=TRANSACTION).status_code == 404
    sign_in_as(client, "owner-a")
    assert len(client.get(url).json()) == 1


def test_dashboard_counts_only_the_signed_in_users_data(owner_a_records):
    client, _ = owner_a_records
    client.post("/serenity-api/accounts", json={**ACCOUNT, "name": "B Checking",
                                                "opening_balance": "7.00"})
    b_summary = client.get("/serenity-api/dashboard/summary").json()
    assert b_summary["account_count"] == 1
    assert b_summary["total_balance"] == "7.00"
    assert b_summary["debt_balance"] == "0.00"
    assert b_summary["investment_value"] == "0.00"
    assert b_summary["monthly_bill_total"] == "0.00"
    assert b_summary["net_worth"] == "7.00"

    sign_in_as(client, "owner-a")
    a_summary = client.get("/serenity-api/dashboard/summary").json()
    assert a_summary["total_balance"] == "90.00"
    # 90.00 + 45.00 invested - 50.00 debt
    assert a_summary["net_worth"] == "85.00"


def test_exports_contain_only_the_signed_in_users_records(owner_a_records):
    client, _ = owner_a_records
    backup = client.get("/serenity-api/export").json()
    for key in ("accounts", "transactions", "transaction_corrections", "businesses",
                "dependents", "bills", "debts", "investments"):
        assert backup[key] == [], key
    csv_text = client.get("/serenity-api/export/transactions.csv").text
    assert csv_text.strip().count("\n") == 0          # header row only
    assert "Owner A purchase" not in csv_text

    sign_in_as(client, "owner-a")
    a_backup = client.get("/serenity-api/export").json()
    assert [a["name"] for a in a_backup["accounts"]] == ["A Checking"]
    assert "Owner A purchase" in client.get("/serenity-api/export/transactions.csv").text
