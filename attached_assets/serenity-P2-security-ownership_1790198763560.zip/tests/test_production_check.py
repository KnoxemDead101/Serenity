"""The production row check reports counts only and never writes."""

import os
import sqlite3
import subprocess
import sys
from pathlib import Path

from test_migrations import run_alembic

SCRIPT = str(Path(__file__).resolve().parents[1] / "scripts" / "check_production_rows.py")


def run_check(database_path):
    env = {**os.environ, "SERENITY_CHECK_DATABASE_URL": f"sqlite:///{database_path}"}
    return subprocess.run(
        [sys.executable, SCRIPT],
        env=env, capture_output=True, text=True,
    )


def test_reports_empty_database_as_safe(tmp_path):
    database_path = tmp_path / "empty.db"
    run_alembic(database_path, "upgrade", "head")
    result = run_check(database_path)
    assert result.returncode == 0, result.stderr
    assert "no financial rows" in result.stdout


def test_reports_unowned_rows_without_printing_their_contents(tmp_path):
    database_path = tmp_path / "legacy.db"
    run_alembic(database_path, "upgrade", "0007_business_and_dependents")
    connection = sqlite3.connect(database_path)
    connection.execute(
        "INSERT INTO accounts (id, name, account_type, classification, "
        "opening_balance_cents, active, created_at, updated_at) VALUES "
        "(1, 'Secret Savings', 'Savings', 'Personal', 99999, 1, "
        "'2026-09-23 12:00:00', '2026-09-23 12:00:00')"
    )
    connection.commit()
    connection.close()

    result = run_check(database_path)
    assert result.returncode == 0, result.stderr
    assert "STOP before publishing" in result.stdout
    assert "Secret Savings" not in result.stdout
    assert "99999" not in result.stdout
    # Still exactly one row: the check changed nothing.
    connection = sqlite3.connect(database_path)
    assert connection.execute("SELECT COUNT(*) FROM accounts").fetchone()[0] == 1
    connection.close()


def test_refuses_to_run_without_an_explicit_url():
    env = {k: v for k, v in os.environ.items() if k != "SERENITY_CHECK_DATABASE_URL"}
    result = subprocess.run(
        [sys.executable, SCRIPT],
        env=env, capture_output=True, text=True,
    )
    assert result.returncode == 2
