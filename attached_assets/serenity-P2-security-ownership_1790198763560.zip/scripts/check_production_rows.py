"""
READ-ONLY check: how many financial rows exist, and do they have an owner?

WHY
---
Replit Publish copies the development database's STRUCTURE to production,
but it never runs Alembic, so migration 0008's data step (giving existing
rows an owner) does not happen in production. If production already holds
rows, making `owner_id` NOT NULL there would fail, or those rows would be
invisible to everyone. Run this BEFORE publishing the ownership change so
you know which case you're in.

WHAT IT DOES
------------
- Connects to the database in SERENITY_CHECK_DATABASE_URL (a separate name
  on purpose, so it's never pointed at a database by accident).
- Opens a READ ONLY transaction: PostgreSQL itself refuses any write.
- Prints, per table: whether it exists, the row count, whether it has an
  owner_id column, and how many rows have no owner.
- Prints COUNTS ONLY. It never prints names, amounts, owner ids or the
  connection string.

HOW TO RUN (Replit Shell)
-------------------------
    SERENITY_CHECK_DATABASE_URL="<production connection string>" \\
        python scripts/check_production_rows.py

Don't paste the connection string into chat, docs or commits.
It changes nothing, so it's safe to run as often as you like.
"""

import os
import sys

from sqlalchemy import create_engine, inspect, text

TABLES = (
    "accounts",
    "transactions",
    "transaction_corrections",
    "businesses",
    "dependents",
    "bills",
    "debts",
    "investments",
    "income_profiles",
)


def main() -> int:
    url = os.getenv("SERENITY_CHECK_DATABASE_URL", "").strip()
    if not url:
        print("Set SERENITY_CHECK_DATABASE_URL to the database to inspect.", file=sys.stderr)
        return 2
    if url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://"):]
    if url.startswith("postgresql://"):
        url = "postgresql+psycopg://" + url[len("postgresql://"):]

    engine = create_engine(url)
    try:
        with engine.connect() as connection:
            if connection.dialect.name == "postgresql":
                connection.execute(text("SET TRANSACTION READ ONLY"))
            inspector = inspect(connection)
            existing = set(inspector.get_table_names())

            version = None
            if "alembic_version" in existing:
                version = connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar()
            print(f"alembic_version: {version or '(none - normal for Replit production)'}")
            print(f"{'table':<26}{'rows':>8}  owner_id column  rows without owner")

            total_rows = 0
            total_unowned = 0
            for table in TABLES:
                if table not in existing:
                    print(f"{table:<26}{'-':>8}  (table not present)")
                    continue
                # Table names come from the fixed TABLES list above, never from input.
                rows = connection.execute(text(f"SELECT COUNT(*) FROM {table}")).scalar()
                columns = {c["name"] for c in inspector.get_columns(table)}
                if "owner_id" in columns:
                    unowned = connection.execute(
                        text(f"SELECT COUNT(*) FROM {table} WHERE owner_id IS NULL OR owner_id = ''")
                    ).scalar()
                    owner_col = "yes"
                else:
                    unowned = rows
                    owner_col = "NO"
                total_rows += rows
                total_unowned += unowned
                print(f"{table:<26}{rows:>8}  {owner_col:<15}  {unowned}")
            connection.rollback()
    finally:
        engine.dispose()

    print()
    if total_rows == 0:
        print("RESULT: no financial rows. Publishing the ownership schema is safe;")
        print("        nothing needs an owner assigned.")
    elif total_unowned == 0:
        print("RESULT: every row already has an owner. No data step needed.")
    else:
        print(f"RESULT: {total_unowned} row(s) have no owner. STOP before publishing.")
        print("        Follow 'Production data and migration 0008' in docs/security.md.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
