# Serenity security and ownership

This file covers how Serenity decides who you are, how it keeps each
person's records separate, how to smoke-test sign-in by hand, and how to
handle production data when the ownership schema is published.

It never contains keys, cookies, tokens or real user ids. Keep it that way.

---

## 1. Sign-in flow (who are you?)

```
Browser (/sign-in)                 Serenity (FastAPI)                     Clerk
------------------                 ------------------                     -----
auth.js loads Clerk  ─────────────────────────────────────────────────▶  sign-in UI
user signs in        ◀─────────────────────────────────────────────────  short-lived token
POST /serenity-api/auth/session
  Authorization: Bearer <token>  ─▶ verify_clerk_token()  ────────────▶  /v1/sessions/{sid}
                                    (uses CLERK_SECRET_KEY, server-side)  "active, user_…"
                                 ◀─ Set-Cookie: serenity_session
                                    (HMAC-signed with SESSION_SECRET,
                                     HttpOnly, Secure, SameSite=Lax, 12 h)
```

After that, every request carries the `serenity_session` cookie:

| Request type | Dependency | Signed out / expired / tampered |
| --- | --- | --- |
| Pages (`/`, `/accounts`, `/finances`, `/setup`, `/income`) | `require_page_session` | 307 → `/sign-in?next=<page>` |
| APIs and downloads (`/serenity-api/...`) | `require_session` | 401 JSON |

`frontend/static/js/api.js` turns any 401 into a redirect to
`/sign-in?next=<current page>`, and `auth.js` only follows a `next` that
stays on the same site (no open redirect).

Secrets live only in Replit Secrets: `CLERK_SECRET_KEY`,
`CLERK_PUBLISHABLE_KEY`, `SESSION_SECRET`. Never in code, docs or logs.

## 2. Ownership (whose records are these?)

Every financial table has an `owner_id` column (the Clerk user id).

```
cookie ──▶ require_session() ──▶ user_id
                                   │  route passes it explicitly
                                   ▼
                     service(db, ..., owner_id=user_id)
                                   │  require_owner_id(): None/""/"   " → MissingOwnerError
                                   ▼
          SELECT ... WHERE owner_id = :user_id      (reads)
          Model(owner_id=user_id, ...)              (creates)
```

Rules the code follows:

- `owner_id` is **required**. There is no default owner and no
  "test-user" fallback. A missing owner is an error, never a guess.
- Reads are always filtered by owner. Another person's record id returns
  **404**, exactly like a record that doesn't exist (so ids can't be probed).
- Transactions and corrections inherit the owner of their account.
- Business and dependent links are looked up with the **account's** owner,
  so you can't attach someone else's business id to your transaction
  (422 "doesn't exist").
- Dashboard totals and both exports (JSON backup, transactions CSV) only
  include the signed-in owner's rows.
- Tests use FastAPI `dependency_overrides` to sign in as `test-owner`;
  production code has no bypass switch. `tests/test_auth.py` fails if one
  is ever added back.

Regression tests: `tests/test_owner_isolation.py` (two real signed-in users),
`tests/test_auth.py` (redirects, 401s, tampered and expired cookies), and the
service tests (missing owner is rejected).

## 3. Manual Clerk smoke test (do this after each auth-related publish)

Use a private/incognito window so no old cookie is reused.

1. **Signed out redirect** – open `/accounts`. You land on
   `/sign-in?next=/accounts`.
2. **Sign in** – sign in with your invited Clerk account. You return to
   `/accounts`.
3. **Dashboard** – open `/`. Totals load with no error message.
4. **Pages** – open Accounts, Finances, Income and Setup. Each loads; the
   mobile menu opens and closes on a phone-width window.
5. **API** – open `/serenity-api/accounts` in the same window. You see JSON
   (your own records only).
6. **Export** – on the dashboard, download the JSON backup and the CSV. Both
   download and contain only your data.
7. **Sign out** – click Sign out. You land on the sign-in page.
8. **Protected again** – open `/` and `/serenity-api/accounts`. The page
   redirects to sign-in; the API returns `{"detail": ...}` with 401.
9. **Expired / invalid session** – in DevTools → Application → Cookies,
   edit the `serenity_session` value (change one character) and reload
   `/accounts`. You are sent to sign-in. (A real expiry happens after 12 h.)
10. **Mid-page expiry** – sign in, open `/accounts`, delete the
    `serenity_session` cookie, then try to save something. The page sends you
    to sign-in and brings you back to `/accounts` afterwards.

Don't screenshot or paste cookie values anywhere.

## 4. Production data and migration 0008

**The problem.** Replit Publish copies the development database's
*structure* to production. It does not run Alembic, so 0008's data step
(assigning existing rows to `SERENITY_LEGACY_OWNER_ID`) never runs in
production. If production already has rows without an owner, they either
block the NOT NULL change or become invisible to everyone.

**Development database** (Alembic runs here):

- Empty database: `alembic upgrade head` needs nothing extra.
- Database with rows: set `SERENITY_LEGACY_OWNER_ID` to *your* Clerk user id
  for that one command, e.g.
  `SERENITY_LEGACY_OWNER_ID=<your user id> alembic upgrade head`.
  Without it, 0008 stops with "SERENITY_LEGACY_OWNER_ID is required" rather
  than guess. Your user id is shown in the Clerk dashboard under Users
  (it starts `user_`), or at `/serenity-api/auth/me` while signed in.
  Don't store it in the repo.

**Production** – before publishing the ownership schema:

1. Run the read-only check (it only prints counts):
   `SERENITY_CHECK_DATABASE_URL="<production URL>" python scripts/check_production_rows.py`
2. If it says **no financial rows** or **every row already has an owner**:
   publish normally.
3. If it says **STOP**: don't publish yet. Download a backup from the live
   app first, then choose one, deliberately:
   - **The rows are test data** → accept that Replit's publish will ask to
     drop/recreate or will fail on them, and re-enter data after publishing.
   - **The rows are real** → in Replit's production database tool, inside a
     transaction, add the nullable `owner_id` columns and set them to your
     user id, then publish so the columns become NOT NULL. This is an
     explicit data change: do it yourself, once, after the backup, and
     re-run the check afterwards. (Ask for the exact SQL for your table
     list at that time rather than copying an old snippet.)
4. After publishing, run the smoke test above.

Migration **0009** only adds `owner_id` lookup indexes (`if_not_exists`), so
it is structure-only and safe for Publish to copy.

## 5. Known limitations (accepted for now)

- **Sessions can't be revoked early.** The cookie is stateless (signed, not
  stored), so signing out clears it from *this* browser, but a copied cookie
  stays valid until its 12-hour expiry. Removing a user in Clerk stops new
  sign-ins, not an existing cookie. A server-side session table would fix
  this later.
- **Clerk JS is loaded as `@latest`** from the CDN in `auth.js`. A Clerk
  release could change behaviour without a code change. Pin it to a
  specific version at the next auth task.
- **Invite-only** is enforced by Clerk's settings (restricted sign-ups).
  Serenity itself accepts any valid Clerk session for that instance.
- No rate limiting on the session endpoint beyond what Clerk provides.
