"""
Ownership: every financial record belongs to exactly one signed-in user.

HOW OWNERSHIP FLOWS
-------------------
    Signed request (Serenity session cookie)
        -> auth.require_session()          returns the Clerk user id
        -> route receives it as `user_id`
        -> service(owner_id=user_id)       owner_id is REQUIRED, no default
        -> every query filters by owner_id

There is deliberately NO default owner. If a caller forgets to pass one,
Python raises a TypeError, and `require_owner_id` rejects blank values.
A missing identity must fail loudly, never quietly become some shared
"test user" whose data everyone could see.

Tests use an explicit test owner id through fixtures (tests/conftest.py).
"""

OWNER_ID_MAX_LENGTH = 255


class MissingOwnerError(ValueError):
    """A service was called without a usable owner id."""


def require_owner_id(owner_id: str | None) -> str:
    """Return the owner id, or raise if it is missing, blank or too long."""
    if not isinstance(owner_id, str) or not owner_id.strip():
        raise MissingOwnerError("An owner id is required for financial records.")
    if len(owner_id) > OWNER_ID_MAX_LENGTH:
        raise MissingOwnerError("Owner id is too long.")
    return owner_id
