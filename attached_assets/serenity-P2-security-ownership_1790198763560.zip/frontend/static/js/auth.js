const clerkScriptUrl = "https://cdn.jsdelivr.net/npm/@clerk/clerk-js@latest/dist/clerk.browser.js";
const clerkUiScriptUrl = "https://cdn.jsdelivr.net/npm/@clerk/ui@1.34.0/dist/ui.browser.js";

function loadScript(url) {
  return new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = url;
    script.onload = resolve;
    script.onerror = () => reject(new Error("Unable to load sign-in."));
    document.head.appendChild(script);
  });
}

async function loadClerk() {
  const configResponse = await fetch("/serenity-api/auth/config");
  const config = await configResponse.json();
  if (!config.publishable_key) {
    throw new Error("Sign-in is not configured.");
  }

  await loadScript(clerkUiScriptUrl);
  const script = document.createElement("script");
  script.src = clerkScriptUrl;
  script.setAttribute("data-clerk-publishable-key", config.publishable_key);
  await new Promise((resolve, reject) => {
    script.onload = resolve;
    script.onerror = () => reject(new Error("Unable to load sign-in."));
    document.head.appendChild(script);
  });

  await window.Clerk.load({
    ui: { ClerkUI: window.__internal_ClerkUICtor },
  });
  return window.Clerk;
}

// Only ever send the user to a page on THIS site after sign-in.
// "/accounts" is fine; "//evil.example" or "https://evil.example" is not
// (those would be an "open redirect" someone could use in a phishing link).
function safeNextPath() {
  const next = new URLSearchParams(window.location.search).get("next") || "/";
  try {
    const url = new URL(next, window.location.origin);
    if (url.origin !== window.location.origin) return "/";
    return url.pathname + url.search + url.hash;
  } catch {
    return "/";
  }
}

async function establishSerenitySession(clerk) {
  if (!clerk.session) return false;
  const token = await clerk.session.getToken();
  if (!token) return false;
  const response = await fetch("/serenity-api/auth/session", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) throw new Error("The sign-in session could not be created.");
  window.location.assign(safeNextPath());
  return true;
}

async function showSignIn() {
  const error = document.getElementById("auth-error");
  try {
    const clerk = await loadClerk();
    if (await establishSerenitySession(clerk)) return;
    clerk.mountSignIn(document.getElementById("clerk-sign-in"), {
      afterSignInUrl: window.location.href,
      afterSignUpUrl: window.location.href,
    });
    clerk.addListener(async () => {
      try {
        await establishSerenitySession(clerk);
      } catch (sessionError) {
        error.textContent = sessionError.message;
        error.hidden = false;
      }
    });
  } catch (loadError) {
    error.textContent = loadError.message;
    error.hidden = false;
  }
}

async function signOutOfSerenity() {
  try {
    const clerk = await loadClerk();
    await fetch("/serenity-api/auth/session", { method: "DELETE" });
    await clerk.signOut();
  } finally {
    window.location.assign("/sign-in");
  }
}

if (document.getElementById("clerk-sign-in")) {
  showSignIn();
}
