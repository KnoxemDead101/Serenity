"""
Authentication helpers for the Serenity web application.

HOW SIGN-IN WORKS
-----------------
1. Clerk (a hosted sign-in service) handles passwords, invitations and
   sign-in screens in the browser (frontend/static/js/auth.js).
2. The browser sends Clerk's session token to POST /serenity-api/auth/session.
3. verify_clerk_token() asks Clerk's Backend API, using our secret key,
   whether that session is real and active, and which user it belongs to.
4. Serenity then sets its OWN short-lived cookie (HTTP-only, signed with
   SESSION_SECRET) containing just the Clerk user id and an expiry time.
5. Every protected page/API calls require_session() / require_page_session(),
   which reads that cookie and returns the user id. Services use that id
   as `owner_id` to scope every query (services/ownership.py).

There is deliberately NO bypass switch in this file. Tests replace
require_session / require_page_session with FastAPI dependency overrides
(tests/conftest.py), so production code has no "pretend to be a test user"
path at all.

KNOWN LIMITATION
----------------
Signing out deletes the cookie in that browser. A copied cookie would stay
valid until it expires (at most SESSION_TTL_SECONDS), because sessions
aren't stored server-side. Revoking a session in Clerk does not reach an
already-issued Serenity cookie. Acceptable for a single-user tool; revisit
before inviting others.
"""

import base64
import hashlib
import hmac
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from fastapi import HTTPException, Request, status

AUTH_COOKIE = "serenity_session"
SESSION_TTL_SECONDS = 60 * 60 * 12


def _secret() -> bytes:
    secret = os.getenv("SESSION_SECRET")
    if not secret:
        raise RuntimeError("SESSION_SECRET must be configured")
    return secret.encode("utf-8")


def _encode(value: dict[str, Any]) -> str:
    """JSON payload + HMAC-SHA256 signature, both base64url-encoded."""
    payload = base64.urlsafe_b64encode(
        json.dumps(value, separators=(",", ":")).encode("utf-8")
    ).rstrip(b"=").decode("ascii")
    signature = hmac.new(_secret(), payload.encode("ascii"), hashlib.sha256).digest()
    encoded_signature = base64.urlsafe_b64encode(signature).rstrip(b"=").decode("ascii")
    return f"{payload}.{encoded_signature}"


def _decode(value: str) -> dict[str, Any] | None:
    """Return the session only if the signature matches and it hasn't expired."""
    try:
        payload, signature = value.split(".", 1)
        expected = hmac.new(_secret(), payload.encode("ascii"), hashlib.sha256).digest()
        supplied = base64.urlsafe_b64decode(signature + "=" * (-len(signature) % 4))
        if not hmac.compare_digest(expected, supplied):
            return None
        decoded = base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4))
        session = json.loads(decoded)
        if not isinstance(session, dict) or session.get("expires_at", 0) < time.time():
            return None
        if not session.get("user_id"):
            return None
        return session
    except (ValueError, TypeError, json.JSONDecodeError):
        return None


def issue_session(user_id: str) -> str:
    return _encode(
        {
            "user_id": user_id,
            "expires_at": int(time.time()) + SESSION_TTL_SECONDS,
        }
    )


def current_user(request: Request) -> str | None:
    """The signed-in Clerk user id from Serenity's signed cookie, or None."""
    cookie = request.cookies.get(AUTH_COOKIE)
    if not cookie:
        return None
    session = _decode(cookie)
    return str(session["user_id"]) if session else None


def require_session(request: Request) -> str:
    """API dependency: the user id, or HTTP 401."""
    user_id = current_user(request)
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Sign in required",
        )
    return user_id


def require_page_session(request: Request) -> str:
    """Page dependency: the user id, or a redirect to the sign-in page."""
    user_id = current_user(request)
    if user_id is None:
        next_path = request.url.path
        if request.url.query:
            next_path += f"?{request.url.query}"
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            # quote() keeps "/" readable but encodes "?" and "&" so the page's
            # own query string can't leak into the sign-in page's parameters.
            headers={"Location": f"/sign-in?next={urllib.parse.quote(next_path, safe='/')}"},
            detail="Sign in required",
        )
    return user_id


def _jwt_payload(token: str) -> dict[str, Any] | None:
    """Read the token's claims; Clerk's Backend API performs the real check."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        payload = base64.urlsafe_b64decode(parts[1] + "=" * (-len(parts[1]) % 4))
        claims = json.loads(payload)
        return claims if isinstance(claims, dict) else None
    except (ValueError, TypeError, json.JSONDecodeError):
        return None


def verify_clerk_token(token: str) -> str | None:
    """
    Verify a Clerk session through Clerk's Backend API and return the user id.

    The token's claims are only used to find the session id; the decision
    comes from Clerk's server (session must be "active" and belong to the
    same user), authenticated with CLERK_SECRET_KEY.
    """
    claims = _jwt_payload(token)
    if not claims or not claims.get("sid") or not claims.get("sub"):
        return None
    if claims.get("exp", 0) < time.time():
        return None

    secret = os.getenv("CLERK_SECRET_KEY")
    if not secret:
        return None
    request = urllib.request.Request(
        f"https://api.clerk.com/v1/sessions/{claims['sid']}",
        headers={"Authorization": f"Bearer {secret}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            session = json.loads(response.read())
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, ValueError):
        return None

    if session.get("status") != "active" or session.get("user_id") != claims.get("sub"):
        return None
    return str(claims["sub"])


def bearer_token(request: Request) -> str | None:
    authorization = request.headers.get("Authorization", "")
    scheme, _, token = authorization.partition(" ")
    return token if scheme.lower() == "bearer" and token else None
